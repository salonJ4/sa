CREATE DATABASE IF NOT EXISTS 'inventory-service';
