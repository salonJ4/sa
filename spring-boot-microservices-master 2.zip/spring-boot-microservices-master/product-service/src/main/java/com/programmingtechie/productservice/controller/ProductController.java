package com.programmingtechie.productservice.controller;



import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/product")
@RequiredArgsConstructor
public class ProductController {

   static List<Product> products = new ArrayList<>();


    static {

        Product p1 = new Product("1","phone","phone",1000);
        Product p2 = new Product("2","cloth","cloth",2000);
        Product p3 = new Product("3","fan","fan",3000);
        Product p4 = new Product("4","table","table",4000);
        Product p5 = new Product("5","pen","pen",5000);

        products.add(p1);
        products.add(p2);
        products.add(p3);
        products.add(p4);
        products.add(p5);

    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public  List<Product> getAllProducts() {
        return products;
    }

}
