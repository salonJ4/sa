package com.programmingtechie.orderservice.controller;


import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Transactional
@Slf4j
public class OrderService {

    private final WebClient.Builder webClientBuilder;


    public String placeOrder(OrderRequest orderRequest) {


        System.out.println(orderRequest);
        String orderProductSkuCode = orderRequest.getOrderLineItemsDtoList().get(0).getSkuCode();
        Boolean inventoryResponse = webClientBuilder.build().get()
                .uri("http://localhost:8082/api/inventory",
                        uriBuilder -> uriBuilder.queryParam("skuCode", orderProductSkuCode).build())
                .retrieve()
                .bodyToMono(Boolean.class)
                .block();

        if (inventoryResponse) {
            //orderRepository.save(order);
            return "order placed";
        }
       return null;

    }


}
