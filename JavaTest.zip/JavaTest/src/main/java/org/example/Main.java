package org.example;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;

class Solution {
    public static void main(String[] args) {

        int[] n = {1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 0, 0, 1, 1, 1, 1, 1, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 0, 0, 1, 1, 0, 1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0, 1, 1};
        int x = findMaxLength(n);
        System.out.println(x);
        // int[] n = {1,100,1,1,1,100,1,1,100,1};
        //  int y= minCost(n);
        //    int y =  minCost2(4);
        //    System.out.println(y);
    }
    // dp= 1,100,2,2,3,102,4,5,104,6

    static int minCost(int[] n) {
        int[] dp = new int[n.length];
        dp[0] = n[0];
        if (n.length == 0) return dp[0];

        dp[1] = n[1];
        if (n.length == 1) return dp[1];


        int x = 0;

        for (int i = 2; i < n.length; i++) {
            x = n[i] + Math.min(dp[i - 1], dp[i - 2]);
            dp[i] = x;
        }

        return Math.min(dp[dp.length - 1], dp[dp.length - 2]);
    }

    static int minCost2(int n) {

        int[] dp = new int[n + 1];

        dp[0] = 0;
        if (n == 0) return dp[0];
        dp[1] = 1;
        if (n == 1) return dp[1];
        dp[2] = 1;
        if (n == 2) return dp[2];

        for (int i = 3; i <= n; i++) {

            dp[i] = dp[i - 1] + dp[i - 2] + dp[i - 3];
        }

        return dp[n];

    }

    static int findMaxLength(int[] a) {
        HashMap<Integer, Integer> hashmap = new HashMap<>();
        int ans = 0;
        hashmap.put(0, -1);

        int sum = 0;

        for (int i = 0; i < a.length; i++) {

            if (a[i] == 0) {
                sum = sum + (-1);
            } else {
                sum = sum + 1;
            }

            if (hashmap.containsKey(sum)) {

                int idx = hashmap.get(sum);
                int len = i - idx;
                if (len > ans) {
                    ans = len;
                }

            } else {
                hashmap.put(sum, i);
            }

        }


        return ans;

    }
}