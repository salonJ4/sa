package org.example;

public class TesterH {
    public static void main(String[] args) {



       // Given an integer array nums, move all 0's to the end of it
        // while maintaining the relative order of the non-zero elements.
        //Output: {1,3,12,0,0}




              int[] nums = {0,1,0,3,12};
              int[] res = new int[nums.length];
              int zeroCount = 0;
              int numIndex = 0;


        for(int i=0;i<nums.length;i++){
            if(nums[i]==0){
                zeroCount=zeroCount+1;
            }
            else {
                res[numIndex]=nums[i];
                numIndex=numIndex+1;
            }
        }

        for(int i=numIndex;i<res.length;i++){
            res[i]=0;
        }

        System.out.println(res);


    }
    static synchronized void increaseCount(){
    }

}
