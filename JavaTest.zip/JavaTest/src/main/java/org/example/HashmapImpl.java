package org.example;

import java.util.HashMap;

public class HashmapImpl {

    HashMap<String,Integer> hashMap = new HashMap();

}

class Node{
    String key;
    Node5 next;

}
