package org.example;

import javax.swing.text.html.parser.Entity;
import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;


class Dept{
    int id;
    List<Employee> employees ;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Employee> getEmployees() {
        return employees;
    }

    public void setEmployees(List<Employee> employees) {
        this.employees = employees;
    }
}
public class Employee {
    int id;

    String name;

    int age;

    String gender;

    String department;

    int yearOfJoining;

    double salary;

    public Employee(int id, String name, int age, String gender, String department, int yearOfJoining, double salary) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.department = department;
        this.yearOfJoining = yearOfJoining;
        this.salary = salary;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getDepartment() {
        return department;
    }

    public int getYearOfJoining() {
        return yearOfJoining;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Id : " + id
                + ", Name : " + name
                + ", age : " + age
                + ", Gender : " + gender
                + ", Department : " + department
                + ", Year Of Joining : " + yearOfJoining
                + ", Salary : " + salary;
    }


    public static void main(String[] args) {


        HashMap<String,String> map = new HashMap<>();
        map.put("1","one");
        map.put("2","two");

        System.out.println(map.put("1","one"));





        List<Dept> list= new ArrayList<>();

        Dept dept = new Dept();
        List<Employee> employeeList = new ArrayList<Employee>();
        employeeList.add(new Employee(111, "Jiya Brein", 32, "Female", "HR", 2011, 25000.0));
        employeeList.add(new Employee(122, "Paul Niksui", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        dept.setEmployees(employeeList);
        dept.setId(1);

        Dept dept2 = new Dept();
        List<Employee> employeeList2 = new ArrayList<Employee>();
        employeeList2.add(new Employee(111, "SJ", 32, "Female", "HR", 2011, 25000.0));
        employeeList2.add(new Employee(122, "AB", 25, "Male", "Sales And Marketing", 2015, 13500.0));
        dept2.setEmployees(employeeList);
        dept2.setId(2);

        list.add(dept);
        list.add(dept2);


      List<List<Employee>>list1=
              list.stream().map(e->e.getEmployees().stream().collect(Collectors.toList())).collect(Collectors.toList());



       List<Employee> list2=    list.stream().flatMap(d->d.getEmployees().stream()).collect(Collectors.toList());

 Map<Integer,List<Employee>> l = list.stream().flatMap(d->d.getEmployees().stream()).collect(Collectors.groupingBy(Employee::getAge));


    }
}