package org.example;

import java.util.ArrayList;
import java.util.List;

 class Solution5 {
    public static int[] orderPizza(int[] orderPlaced, int k) {

        List<Integer> list = new ArrayList<>();
        int[] kSize = new int[k];
        int kIndex=0;

        List<int[]> groups = new ArrayList<>();


        for (int j = 0; j < orderPlaced.length-k+1; j++) {

            for (int i = j; i < j + k; i++) {

                kSize[kIndex] = orderPlaced[i];
                kIndex=kIndex+1;

            }

            groups.add(kSize);
            kSize=new int[k];
            kIndex=0;


        }


        int negValue = 0;

        for (int[] h : groups) {

            int[] x = h;

            for (int i = 0; i < x.length; i++) {
                if (x[i] < 0) {
                    negValue = x[i];
                    break;
                }
                else{
                    negValue=0;
                }
            }


            list.add(negValue);



        }
        int[] array = list.stream().mapToInt(Integer::intValue).toArray();
        System.out.println(list);
        return array;


    }

     public static void main(String[] args) {
         int[] x= {-11,-2,19,37,64,-18};

         orderPizza(x,3);
     }

}