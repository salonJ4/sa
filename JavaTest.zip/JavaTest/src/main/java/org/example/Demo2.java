/*
package org.example;

// linked list around a given value.
class GfG {

    */
/* Link list Node *//*

    static class Node {
        int data;
        Node next;
    }

    // A utility function to create a new node
    static Node newNode(int data)
    {
        Node new_node = new Node();
        new_node.data = data;
        new_node.next = null;
        return new_node;
    }

    static Node partition(Node head)
    {
*/
/*//*
/ commenting out partitioning code
        Node smaller = newNode(0);
        Node smallerCopy = smaller;
        Node smallerCopyCopy = smallerCopy;
        Node greater = newNode(0);
        Node greaterCopy = greater;


        while (head!=null){

            if(head.data<x){
                Node temp = newNode(head.data);
           smaller.next=temp;
           smaller=smaller.next;
            }


            else {

                Node temp = newNode(head.data);
               greater.next=temp;
                greater=greater.next;


            }

            head=head.next;

        }


       // if(greaterCopy)
        greaterCopy=greaterCopy.next;

      //  if(smallerCopy.next!=null)
        smallerCopy=smallerCopy.next;

        while (smallerCopy.next!=null){
            smallerCopy=smallerCopy.next;

        }
        smallerCopy.next=greaterCopy;

        return smallerCopyCopy.next;*//*


        Node temp = head;
        Node prev= newNode(0);



        while (head.next!=null){
            if (head.next.data==head.data){

                while (head.next.data==head.data) {
                    head = head.next;

                }

                prev.next=head.next;
                head=head.next;



            }

            else{
                prev=head;
                head=head.next;

            }




        }
        System.out.println(temp);
        return null;
    }

    */
/* Function to print linked list *//*

    static void printList(Node head)
    {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
    }


    static Node removeNthNode(Node head, int n) {
        Node prev = newNode(0);
        int nodeCounter = 0;
        Node temp = head;
        int tempCount = 0;
        Node prevCopy = head;
        Node ans = null;


        while (temp != null) {
            temp = temp.next;
            tempCount = tempCount + 1;
        }

        if (tempCount == 1) {
            return null;
        }


        if (head.data == n) {
            return head.next;
        }

        while (head != null) {

            if (nodeCounter == tempCount - n) {
                prev.next = head.next;
                //  prev=prev.next;
                System.out.println(prevCopy);
                System.out.println(prev);

                if (tempCount == 2) {
                    ans = prev.next;
                    break;
                } else {
                    ans = prevCopy;

                }
            }

                nodeCounter = nodeCounter + 1;
                prev = head;
                head = head.next;

            }



        return ans;

        }

    }

    // Driver code
    public static void main(String[] args)
    {
        */
/* Start with the empty list *//*

        Node head = newNode(1);
        head.next = newNode(2);
     //  head.next.next = newNode(3);
    //    head.next.next.next = newNode(4);
    //    head.next.next.next.next = newNode(5);
    //    head.next.next.next.next.next = newNode(6);
      //  head.next.next.next.next.next.next = newNode(7);


       // head = partition(head);

        int n=2;
       Node x= removeNthNode(head,n);
        printList(x);
    }

*/
