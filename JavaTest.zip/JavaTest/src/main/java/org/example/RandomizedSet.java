package org.example;

import java.util.*;

class RandomizedSet {


    List<Integer> list = new ArrayList<>();
    HashMap<Integer,Integer> hashMap = new HashMap<>();

    public RandomizedSet() {

    }

    public boolean insert(int val) {

        if(!list.contains(val)){
            int index = list.size();
            list.add(val);
            hashMap.put(val,index);
            return true;
        }
        else {
            return false;
        }
    }

    public boolean remove(int val) {
       Object x= val;
       if(hashMap.containsKey(val)){
           hashMap.remove(val);
       }
       return list.remove(x);
    }

    public int getRandom() {

        Random random = new Random();
        int index = random.nextInt(list.size()-1);
       int val =  list.get(index);
       return val;
    }

    public static void main(String[] args) {


    }
}