/*
package org.example;

import java.util.*;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.Arrays;
import java.util.List;


class Solution1 {



   // Find 2nd highest integer number from unsorted array.

 // i.e., int[] arr = {7, 10, 4, 3, 20, 15}

   // Output: 15

    public static void main(String[] args) {

    //   ;

       //


















                 }

    }












    public static String removeDuplicates(String s, int k) {
       int y= s.length();
        Stack<Character> stack = new Stack<>();
        HashMap<Character,Integer> map = new HashMap<>();
        map.put(s.charAt(0),1);
        stack.push(s.charAt(0));


        for (int i = 1; i < s.length(); i++) {

            char current = s.charAt(i);
            while (current==stack.peek()) {
                stack.push(current);
                map.put(s.charAt(i), map.getOrDefault(s.charAt(i), 0) + 1);
                Integer x = map.get(s.charAt(i));
                if (x >= k) {
                    for (int j = 0; j < k; j++) {
                        stack.pop();

                        if(stack.isEmpty()){
                            i=i+1;
                            stack.push(s.charAt(i+1));
                            current = s.charAt(i);
                            continue;

                        }

                    }
                    map.remove(s.charAt(i));
                }


                i = i + 1;
                if(i==s.length()-1){
                  //  stack.push(s.charAt(s.length()-1));
                    break;
                }
                current = s.charAt(i);


            }



            stack.push(current);
            map.put(s.charAt(i),map.getOrDefault(s.charAt(i),0)+1);


        }

        int z= stack.size();
        StringBuilder stringBuilder = new StringBuilder();

        for(int i=0;i<z;i++){
            stringBuilder.append(stack.pop());

        }

        System.out.println(stringBuilder.toString());
        return stringBuilder.toString();
    }











    public static List<String> subdomainVisits(String[] cpdomains) {

        HashMap<String, Integer> hashMap = new HashMap<>();

        for (String x : cpdomains) {
            String[] y = x.split(" ");
            int z = Integer.parseInt(y[0]);
            String str = y[1];
            String[] arr = y[1].split("\\.");

            for (int i = 0; i < arr.length; i++) {
                if (hashMap.containsKey(str)) {
                    int val = hashMap.get(str);
                    hashMap.put(str, val + z);
                } else {
                    hashMap.put(str, z);
                }


                int index = str.indexOf(".");
                if (index != -1) {
                    String result = str.substring(index + 1);
                    str = result;

                }
            }
        }

            Function<Map.Entry<String, Integer>, String> function = (g) -> {
                String s = g.getValue() + " " + g.getKey();
                return s;
            };

        List<String> ansList = hashMap.entrySet().stream().map(function).collect(Collectors.toList());

        System.out.println(ansList);
        return ansList;
    }











    public static void rotate(int[][] matrix) {
        matrix=transposeAndSwap(matrix);
    }

    private static int[][] transposeAndSwap(int[][] matrix) {
        boolean[][] visited = new boolean[matrix.length][matrix[0].length];

        for(int i=0;i<matrix.length;i++){

            for(int j=0;j<matrix[0].length;j++){
                int temp =0;
                temp=matrix[i][j];

                if(visited[i][j]==false && visited[j][i]==false) {
                    matrix[i][j] = matrix[j][i];
                    matrix[j][i] = temp;
                    visited[i][j] = true;
                    visited[j][i] = true;
                }

            }

        }



        for(int i=0;i<matrix.length;i++){
            int start =0;
            int end = matrix[0].length-1;
            int temp =0;

            for(int j=0;j<matrix[0].length/2;j++){

               temp= matrix[i][start];
               matrix[i][start]=matrix[i][end];
               matrix[i][end]=temp;

               start=start+1;
               end=end-1;

            }




        }


        System.out.println(matrix);
        return matrix;

    }


    public static boolean canJump(int[] nums) {


        int farthestIndex=0;
        for(int i= 0;i<nums.length-1;i++){
            int current = nums[i];

            if(current==0 && farthestIndex==i){
                return false;
            }
            farthestIndex = Math.max(i+current,farthestIndex);

            if(farthestIndex>=nums.length-1){
                return true;
            }
        }
        return false;
    }





    public static List<List<Integer>> fourSum(int[] a, int target) {



        boolean allPositive = Arrays.stream(a).allMatch(n -> n > 0);
        if(allPositive && target<0){
            return new ArrayList<>();
        }


        Arrays.sort(a);
        Set<List<Integer>> lists = new HashSet<>();
        List<Integer> integerList = new ArrayList<>();
        int left =0;
        int rifght = a.length-1;


        for(int i =0;i<a.length;i++){


            for(int j=i+1;j<a.length;j++){

                 left = j+1;
                 rifght=a.length-1;


                while (left<=rifght){

                    int sum = a[left]+a[rifght]+a[i]+a[j];
                    if(sum==target){
                        integerList.add(a[left]);
                        integerList.add(a[rifght]);
                        integerList.add(a[i]);
                        integerList.add(a[j]);

                        Collections.sort(integerList);
                        lists.add(integerList);
                        integerList= new ArrayList<>();
                        left=left+1;
                    }
                    else if(sum<=target){
                        left=left+1;
                    }
                    else {
                        rifght=rifght-1;
                    }


                }

            }


        }


        System.out.println(lists);



        return lists.stream().collect(Collectors.toList());

    }




    public static int reverse2(int x) {
        long finalNum = 0;
        while(x!=0){
            int lastDig = x%10;
            finalNum += lastDig;
            finalNum = finalNum*10;
            x= x/10;
        }
        finalNum = finalNum/10;
        if(finalNum > Integer.MAX_VALUE || finalNum<Integer.MIN_VALUE){
            System.out.println(finalNum);
            return 0;
        }
        if(x<0){
            return (int)(-1*finalNum);
        }
        return (int)finalNum;
    }


    public static int reverse(int x) {


        boolean neg=false;

        long res = 0;


        if(x<0){
            neg=true;
        }
        x=Math.abs(x);


        while (x>0){

             int rem =x%10;
            res=(10*res)+rem;
            x=x/10;
        }

        if(res>Integer.MAX_VALUE){
            return 0;
        }
        else {

            if(neg){
                res=res*-1;
                return (int) res;
            }

        }
        return (int) res;
    }




    public static long getMaximumScore(List<Integer> stockPrice) {

        boolean[] visited = new boolean[stockPrice.size()];
        List<Integer> list = new ArrayList<>();
        List<Long> longs = new ArrayList<>();

        for(int i=0;i<stockPrice.size();i++){

            for(int j=i+1;j<stockPrice.size();j++){


                if(stockPrice.get(j)-stockPrice.get(i)==j-i){

                    if(visited[i]==false ) {
                        list.add(stockPrice.get(i));

                    }

                    if(visited[j]==false){
                        list.add(stockPrice.get(j));
                    }

                    visited[i]=true;
                    visited[j]=true;
                }



            }

            long sum = list.stream()
                    .mapToLong(Integer::intValue)
                    .sum();


            longs.add(sum);
            sum=0;
            list=new ArrayList<>();
        }


        System.out.println(longs.stream().max(Comparator.comparingInt(Long::intValue)).get());
        return longs.stream().max(Comparator.comparingInt(Long::intValue)).get();

    }



    public static List<String> letterCombinations(String digits) {

        HashMap<String, String> stringHashMap = new HashMap<>();
        List<String> list = new ArrayList<>();
        List<Character> characters=new ArrayList<>();
        List<String> y;

        stringHashMap.put("2", "abc");
        stringHashMap.put("3", "def");
        stringHashMap.put("4", "ghi");
        stringHashMap.put("5", "jkl");
        stringHashMap.put("6", "mno");
        stringHashMap.put("7", "pqrs");
        stringHashMap.put("8", "tuv");
        stringHashMap.put("9", "wxyz");

        if(digits.length()==0){
            return new ArrayList<>();
        }



        for (int i = 0; i < digits.length(); i++) {
            String x=(stringHashMap.get(Character.toString(digits.charAt(i))));

            list.add(x);
        }


        if (list.size() == 1) {
            if(list.get(0).length()==3) {
               characters = Arrays.asList(list.get(0).charAt(0), list.get(0).charAt(1), list.get(0).charAt(2));
            }

            if(list.get(0).length()==4) {
                characters = Arrays.asList(list.get(0).charAt(0), list.get(0).charAt(1), list.get(0).charAt(2), list.get(0).charAt(3));
            }


            List<String> x = characters.stream().map(c -> Character.toString(c)).collect(Collectors.toList());
            System.out.println(x);
            return x;
        }


        if (digits.length() == 3) {
            y = iterateOverTwoListsAndGetValue(list.get(1), list.get(2));
            List<String> ans= makeFinalPair(y, list.get(0));
            return ans;


        }

        else if(digits.length()==4){
            y = iterateOverTwoListsAndGetValue(list.get(2), list.get(3));
            List<String> x= makeFinalPair(y, list.get(1));
            List<String> ans = makeFinalPair(x,list.get(0));
            System.out.println(ans);
            return ans;


        }

        else {
            y = iterateOverTwoListsAndGetValue(list.get(0), list.get(1));
            return y;
        }
    }




    private static List<String> makeFinalPair(List<String> y, String s) {

        StringBuilder stringBuilder = new StringBuilder();
        List<String> stringList = new ArrayList<>();

        for(int i=0;i<s.length();i++){
            for(String j:y){
                stringBuilder.append(s.charAt(i));
                stringBuilder.append(j);
                stringList.add(stringBuilder.toString());
                stringBuilder=new StringBuilder();
            }
        }
        return stringList;
    }

    private static List<String> iterateOverTwoListsAndGetValue(String string, String s) {

        StringBuilder stringBuilder = new StringBuilder();
        List<String> stringList = new ArrayList<>();

        for(int i=0;i<string.length();i++){
            for(int j=0;j<s.length();j++){

                stringBuilder.append(string.charAt(i));
                stringBuilder.append(s.charAt(j));

                stringList.add(stringBuilder.toString());
                stringBuilder=new StringBuilder();

            }
        }
        return stringList;
    }


    public static List<String> getLongestSubsequence(String[] words, String[] groups) {


        List<String> list2 = new ArrayList<>();
        if(groups.length==1){
            list2.add(words[0]);
            return list2;
        }

        StringBuilder stringBuilder = new StringBuilder();
        List<String> list = new ArrayList<>();
        boolean executed=false;

        for(int i=0;i<words.length-1;i++){

            if(groups[i]!=groups[i+1]){
                stringBuilder.append(words[i]);
                executed=true;

                if(i==words.length-2){
                    list.add(stringBuilder.toString());
                }



            }
            else {

                stringBuilder.append(words[i]);

                list.add(stringBuilder.toString());
                stringBuilder= new StringBuilder();

            }


        }

        stringBuilder = new StringBuilder(list.get(list.size()-1));

        String x1= list.get(list.size()-1);
        x1= x1.concat(words[words.length-1]);

        list.remove(list.get(list.size()-1));
        list.add(x1);

        if(!executed){
            return Arrays.asList(words[0]);
        }

        String x=  list.stream().max((s1,s2)->Integer.compare(s1.length(),s2.length())).get();
        List<String> strings = new ArrayList<>();
        char[] c= x.toCharArray();

        for(char y:c){
            strings.add(Character.toString(y));
        }
        return strings;
    }











    public static int leastInterval(char[] a, int n) {

      //  Arrays.stream(a).

        int ind=-1;

        int idleCount =0;
        int counter=0;

        List<Character> charList = new ArrayList<>();
        for (char c : a) {
            charList.add(c);
        }



        Map<Character, Integer> charCountMap = new HashMap<>();
        for (char c : charList) {
            charCountMap.put(c, charCountMap.getOrDefault(c, 0) + 1);
        }


        List<Character> listX = new ArrayList<>();
        List<List<Character>> list =  new ArrayList<>();

        for(Map.Entry j:charCountMap.entrySet()){

            int val= (int) j.getValue();
            for(int i=0;i<val;i++){
                listX.add((Character) j.getKey());
            }

            list.add(listX);
            listX= new ArrayList<>();
        }





        int maxSize = list.stream()
                .mapToInt(List::size)
                .max()
                .orElse(0);

        for(int i=0;i<maxSize;i++){


            for(List<Character> list1 : list) {

                if (i < list1.size()) {
                    if (list1.get(i) != null) {
                        ind = ind + 1;
                        counter = counter + 1;



                    }

                }
            }


            if (ind<n){
                if(counter==charList.size()){
                    System.out.println(counter+idleCount);
                   return counter+idleCount;
                }
               idleCount=idleCount+n-ind;
            }

            n=n;
            ind=-1;

        }


        System.out.println(counter+idleCount);
    return counter+idleCount;
    }




    public int maxSubArray(int[] nums) {

        int y=0;
        boolean rotated=false;
        for(int i=0;i<nums.length;i++){

            if(nums[i+1]<nums[i]){
                y= nums[i+1];
                rotated=true;
                break;
            }
        }

        if(!rotated){
            y=nums[0];
        }

        return y;
    }











    // sliding window problem
    public static int[] merge1(String s, String t){
        int start =0;
        int end = t.length();
        List<Integer> list = new ArrayList<>();

        String  sub=s.substring(start,end);

        while (end<=s.length()) {
            if (areAnagrams(sub, t)) {
                list.add(start);

                if(end>=s.length()){
                    break;
                }

                StringBuilder stringBuilder = new StringBuilder(sub);
                stringBuilder.deleteCharAt(0);
                stringBuilder.append(s.charAt(end));

                end = end + 1;
                start=start+1;

                sub = stringBuilder.toString();

                if(end>s.length()||start>=end){
                    break;
                }


            }
        }

        int[] array = list.stream().mapToInt(Integer::intValue).toArray();

        Arrays.stream(array).forEach(System.out::println);
        return array;

    }

    public static boolean areAnagrams(String str1, String str2) {
        // Remove all the white spaces from the strings and convert them to lowercase
        str1 = str1.replaceAll("\\s", "").toLowerCase();
        str2 = str2.replaceAll("\\s", "").toLowerCase();

        // Check if the lengths of the two strings are equal
        if (str1.length() != str2.length()) {
            return false;
        }

        // Convert the strings to char arrays and sort them
        char[] charArray1 = str1.toCharArray();
        char[] charArray2 = str2.toCharArray();

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // Compare sorted char arrays
        return Arrays.equals(charArray1, charArray2);
    }







    public static int[][] merge(int[][] intervals,int[] interval1) {


        int[][] newArray=new int[intervals.length+1][];
        int newArrayIndex= 0;
        int x1=interval1[0];
        boolean visited = false;

        for(int i=0;i<=newArray.length-1;i++) {



            if (x1 <= intervals[i][1] && visited==false) {
                newArray[newArrayIndex]=interval1;
                visited=true;
                newArrayIndex=newArrayIndex+1;
                newArray[newArrayIndex] = intervals[i];
                newArrayIndex=newArrayIndex+1;

                continue;
            }
            newArray[newArrayIndex] = intervals[i];
            newArrayIndex = newArrayIndex + 1;

        }



        intervals=newArray;


        int[] entry = new int[2];
        Arrays.sort(intervals, Comparator.comparingInt(row -> row[0]));
        Stack<int[]> stack = new Stack<>();
        stack.push(intervals[0]);

        for(int i=1;i<intervals.length;i++){

            int[] x= intervals[i];
            int y[]=stack.peek();

            if(y[1]>=x[0]){

                entry[0]= y[0];



                if(y[1]>=x[1]){
                    entry[1]=y[1];

                }



                else{
                    entry[1]=x[1];
                }

                stack.pop();
                stack.push(entry);


                entry= new int[2];

            }
            else {
                stack.push(intervals[i]);
            }

        }


       int y = stack.size();
        int[][] result = new int[y][];

        for(int i=y-1;i>=0;i--){

            result[i]=stack.pop();

        }


        System.out.println(result);



        return result;

    }



    public static String a(String path) {

        Stack<String> s =new Stack<>();
        String res;
        for(int i=0;i<path.length();i++){
            if(path.charAt(i)=='/'){
                continue;
            }
            String temp=new String("");
            while(i<path.length() && path.charAt(i)!='/'){
                temp=temp+path.charAt(i);
                i++;
            }
            if(temp.equals(".") ){
                continue;
            }
            else if(temp.equals(".."))
            { if(s.size()>0){
                s.pop();
            }

            }
            else{
                s.push(temp);
            }
        }
        String ans= new String("");
        while(!s.isEmpty()){
            ans="/"+s.pop()+ans;
        }
        if(ans.equals("")){
            ans="/";
        }
        return ans;

    }













    public static String intToRoman(int num) {

        StringBuilder stringBuilder = new StringBuilder();

        char[] c= Integer.toString(num).toCharArray();
        int maxLength =c.length;

        for(int i=0;i<c.length;i++) {
            if (maxLength==4) {
                stringBuilder.append(getThousandsValue(c[i]));

            } else if (maxLength == 3) {
                stringBuilder.append(getHundrendsValue(c[i]));
            } else if (maxLength == 2) {
                stringBuilder.append(getTensValue(c[i]));

            }  else {

                int x=c[i]-'0';
                if(x!=0) {
                    stringBuilder.append(getsOnesValue(c[i]));
                }
            }


            maxLength=maxLength-1;

        }

        return stringBuilder.toString();
    }


    private static String getThousandsValue(char c) {
        int x= c -'0';
        StringBuilder s=new StringBuilder();
        for(int i=1;i<=x;i++){
            s.append("M");
        }

        return s.toString();
    }
    private static String getHundrendsValue(char c) {

        List<String> strings = Arrays.asList("C","CC","CCC","CD","D","DC","DCC","DCCC","CM","M");
        int x=  c - '0';
        int index = x-1;
        return strings.get(index);

    }


    private static String getTensValue(char c) {

        List<String> strings = Arrays.asList("X","XX","XXX","XL","L","LX","LXX","LXXX","XC");
        int x=  c - '0';
        int index = x-1;
        return strings.get(index);
    }
    private static String getsOnesValue(char c) {
        List<String> strings = Arrays.asList("I","II","III","IV","V","VI","VII","VIII","IX");
        int x=  c - '0';
        int index = x-1;
        return strings.get(index);
    }


    public static boolean isSubsequence(String t, String s) {

        int sIndex =0;
        StringBuilder stringBuilder = new StringBuilder();


        for(int i=0;i<t.length();i++){
            if(t.charAt(i)==s.charAt(sIndex)){
                stringBuilder.append(t.charAt(i));
                sIndex=sIndex+1;
            }
        }

        if(stringBuilder.toString().equals(s)){
            return true;
        }
        else {
            return false;
        }


    }















    public  List<Integer> getPermutations(String[] s,String test){


        List<List<String>> listList = new ArrayList<>();
        List<List<String>> anslistList = new ArrayList<>();
        List<List<String>> res = new ArrayList<>();
        listList.add(Arrays.stream(s).collect(Collectors.toList()));
        List<String> list = new ArrayList<>(Arrays.stream(s).collect(Collectors.toList()));
        List<Integer> finalAns = new ArrayList<>();

        for(int i=0;i<list.size();i++){
            for(List<String> list1 : listList){

                anslistList.addAll(getPermut(list1,i,anslistList));
                res.addAll(anslistList);

            }

            listList = new ArrayList<>();
            listList.addAll(anslistList);
            anslistList= new ArrayList<>();

        }

        res=res.stream().distinct().collect(Collectors.toList());


        List<String> list1 = new ArrayList<>();
        String result;
        for(List<String> listg:res){
           result = listg.stream()
                    .collect(Collectors.joining());
            list1.add(result);

        }



        for(String x:list1){
            if(test.contains(x)){
                int index = test.indexOf(x);
                finalAns.add(index);
            }
        }

        System.out.println(finalAns);
        return finalAns;


    }

    private static List<List<String>> getPermut(List<String> list, int i, List<List<String>> anslistList) {
        anslistList=new ArrayList<>();
       for(int k=i;k<list.size();k++){
          String[] s4= swapStrings(i,k,list);
          anslistList.add(Arrays.stream(s4).collect(Collectors.toList()));
       }

       return anslistList;
    }


    static String[] swapStrings(int i, int j, List<String> s){


       String[] copy = s.stream().toArray(String[]::new);
        String s1 = copy[i];
        copy[i]=copy[j];
        copy[j]=s1;

        return copy;

    }












    public static int gainMaxValue(List<Integer> security_val, int k) {

      Integer[] arr=  security_val.stream().toArray(Integer[]::new);
      List<Integer> val= new ArrayList<>();
      int max = 0;

      for(int i=0;i< arr.length;i++){
          int curr= 0;
          for(int j=i;j< arr.length;j=j+k+k){


              curr = curr + arr[j];
            if(j+k<arr.length) {
                curr = curr + arr[j + k];
            }
            if(curr>max){
                max=curr;
            }


          }
          val.add(curr);
    }
      return val.stream().max(Integer::compareTo).get();
    }

    public static int minMeetingRooms(int[][] meetings) {
        if (meetings.length == 0) {
            return 0;
        }

        int roomCount = 1;
        Arrays.sort(meetings, Comparator.comparingInt(row -> row[0]));

        for(int i=0;i<meetings.length-1;i++){

            if(meetings[i][1]<=meetings[i+1][0]){
                continue;
            }
            else{
                roomCount=roomCount+1;
            }


        }

        return roomCount;

    }


}*/
