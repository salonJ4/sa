package org.example;

import java.util.Arrays;
import java.util.Comparator;

class Emp implements Comparable<Emp> {
    private String name;
    private int age;
    private double salary;


    public static Comparator<Emp> nameComp = new Comparator<Emp>() {
        @Override
        public int compare(Emp o1, Emp o2) {
            return o1.getName().compareTo(o2.getName());
        }
    };
    public Emp() {
        // Default constructor
    }

    public Emp(String name, int age, double salary) {
        this.name = name;
        this.age = age;
        this.salary = salary;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }

    /*@Override
    public String toString() {
        return "Employee{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", salary=" + salary +
                '}';
    }*/

     @Override
     public int compareTo(Emp o) {
         return o.age-this.age;
     }

     public static void main(String[] args) {

        Emp[] e= new Emp[3];
        e[0]= new Emp("b,",10,20.0);
        e[1]= new Emp("a,",9,20.0);
        e[2]= new Emp("c,",12,20.0);
         System.out.println(e[0]);
         System.out.println(e[0]);


     //    Arrays.sort(e,nameComp);
/*
         Arrays.sort(e,Comparator.comparingInt(Emp::getAge));

         System.out.println(e);
         Arrays.stream(e).forEach(System.out::println);*/


     }
 }
