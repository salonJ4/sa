package org.example;

import java.util.*;
import java.util.function.Function;

class Afg {

    //Given an array of integers.
    // Find maximum number of non-intersecting elemnts of length 2(adjacent elements) having same sum.
    public static void main(String[] args) {

        int a[] = {10,1,3,1,2,2,1,0,4};
        // ouput: 3
        // Explanation: non-intersecting adjacent pairs having sum = 4 are (1,3),(2,2) and (0,4)


        List<Integer> list = new ArrayList<>();
        List<List<Integer>> indexList = new ArrayList<>();
        list.add(a[0] + a[1]);
        indexList.add(Arrays.asList(0,1));

        for (int i = 1; i < a.length - 1; i++) {
            int sum = a[i] + a[i + 1];

            if (list.get(list.size()-1)==sum) {

                if(indexList.get(indexList.size()-1).contains(i)){
                 continue;
                }

                else {
                    indexList.add(Arrays.asList(i,i+1));
                    list.add(sum);
                }
            }
            else {
                list.add(sum);
                indexList.add(Arrays.asList(i,i+1));

            }
        }

            HashMap<Integer, Integer> map = new HashMap<>();

            for (Integer x : list) {
                map.put(x, map.getOrDefault(x, 0) + 1);
            }

        System.out.println(map);


          int x=  map.entrySet().stream().max(Map.Entry.comparingByValue()).get().getValue();
        System.out.println(x);
        }

    }
