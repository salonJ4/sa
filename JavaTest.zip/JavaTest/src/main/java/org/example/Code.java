//package org.example;
//
//import java.util.*;
//import java.util.stream.Collectors;
//
//class Code {
//    public static void main(String[] args) {
//
//        List<Integer> list = Arrays.asList(1, 2, 1, 2, 10, 11, 100, 1000, 13, 5, 6, 3, 4, 3);
//        //List<Integer> list2 =  list.stream().filter(integer -> Integer.toString(integer).startsWith("1")).collect(Collectors.toList());
//
//        //HashSet<Integer> hashSet = new HashSet<>();
//        //List<Integer> list1 =  list.stream().filter(i->hashSet.add(i)).collect(Collectors.toList());
//
//        HashMap<Integer, Integer> hashMap = new HashMap<>();
//        //for(int i=0;i<list.size();i++) {
//        //   hashMap.put(list.get(i),)
//        //}
//
//        //list.stream().distinct().forEach(System.out::println);
//
//
//        // for(int i=0;i<list.size();i++) {
//        //  hashMap.put(list.get(i),hashMap.getOrDefault(list.get(i),0)+1);
//        //}
//        //  hashMap.entrySet().stream().filter(e->e.getValue()==1).map(e->e.getKey()).forEach(System.out::println);
//
//        //  int x=list.stream().max(Integer::compareTo).get();
//        //  System.out.println(x);
//
//        int[] arr = new int[list.size()];
//
//        for (int i = 0; i < list.size(); i++) {
//            arr[i] = list.get(i);
//        }
//
//        for (int i = arr.length - 1; i >= 0; i--) {
//            System.out.println(arr[i]);
//        }
//
//
//    }
//
//    inOrder(TreeNode root){
//
//        if(root==null){
//            return ;
//        }
//
//        //if(root.left.data<root) {
//            inOrder(root.left);
//        }
//        System.out.println(root);
//
//        if(root.right.data>root) {
//            inOrder(root.right);
//        }
//
//
//
//    }
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//    public static int subarraySum(int[] nums, int k) {
//
//        //List<Integer> list = new ArrayList<>();
//        int count =0;
//        int res = 0;
//
//
//        for (int i = 0; i < nums.length; i++) {
//
//            int first = i;
//            res = 0;
//
//            while (first <= nums.length-1) {
//                res = res+ nums[first];
//
//                if(res==k){
//                   count = count+1;
//                }
//
//                first=first+1;
//
//                }
//
//
//            }
//
//
//        return count;
//    }
//
//
//
//
//
//
//    public static int minimumLength(String s) {
//
//        int high = s.length()-1;
//        int low =0;
//        String y = new String(s);
//
//        while (low<high){
//
//            high=y.length()-1;
//            low =0;
//
//            if(y.charAt(low)==y.charAt(high)){
//              y= checkForSubsequentHigh(y.charAt(high),high,y);
//              y=  checkForSubsequentLow(y.charAt(low),low,y);
//
//              if(y.length()==0){
//                  return 0;
//              }
//
//              if(y.length()==1){
//                  return y.length();
//              }
//
//            }
//            else{
//                return y.length();
//            }
//
//
//        }
//
//        return y.length();
//
//    }
//
//    private static String checkForSubsequentLow(char c, int low, String s) {
//
//       StringBuilder stringBuilder = new StringBuilder(s);
//       while (stringBuilder.toString().charAt(low)==c){
//
//
//           if(stringBuilder.length()>=1) {
//
//               stringBuilder.deleteCharAt(low);
//
//
//           }
//
//           if(stringBuilder.length()==0){
//               break;
//           }
//
//       }
//       return stringBuilder.toString();
//    }
//
//    private static String checkForSubsequentHigh(char c, int high, String s) {
//
//        StringBuilder stringBuilder = new StringBuilder(s);
//        while (stringBuilder.toString().charAt(high)==c){
//           stringBuilder.deleteCharAt(high);
//
//
//           high=high-1;
//
//            if(high==0){
//                break;
//            }
//
//
//        }
//
//        return stringBuilder.toString();
//    }
//
//
//    public static int bagOfTokensScore(int[] tokens, int power) {
//
//        Arrays.sort(tokens);
//        boolean[] visited = new boolean[tokens.length];
//        int lastIndex = tokens.length-1;
//        int maxScore =0;
//
//
//        for(int i=0;i<tokens.length;i++){
//
//            if(tokens[i]<=power){
//
//                visited[i]=true;
//                maxScore=maxScore+1;
//                power=power-tokens[i];
//
//            }
//
//            else {
//
//                if (maxScore >= 1) {
//
//                    if (visited[lastIndex] == false) {
//                        maxScore = maxScore - 1;
//                        power = power + tokens[lastIndex];
//                        visited[lastIndex] = true;
//                        lastIndex = lastIndex - 1;
//                        i=i-1;
//
//
//                    }
//                }
//
//            }
//        }
//
//        return maxScore;
//    }
//
//
//
//
//
//
//
//    public static List<List<Integer>> subsets(int[] nums) {
//
//        List<List<Integer>> res = new ArrayList<>();
//        List<Integer> temp = new ArrayList<>();
//        res.add(temp);
//
//        for (int j = 0; j < nums.length; j++) {
//
//
//            int y = res.size();
//            for (int i = 0; i < y; i++) {
//                temp = new ArrayList<>(res.get(i));
//                temp.add(nums[j]);
//
//             List<Integer> s=   new ArrayList<>(temp);
//                res.add(s);
//            }
//
//        }
//        return res;
//    }
//
//
//
//
//
//
//
//
//
//
//
//
//    public static int minDistance(String word1, String word2) {
//
//
//        int m = word2.length();
//        int n = word1.length();
//        int[][] dp = new int[m+1][n+1];
//
//        dp[0][0]=0;
//
//
//      int   index=1;
//        for(int i=1;i<=n;i++){
//            dp[0][i]= index;
//            index=index+1;
//
//        }
//
//        index=1;
//        for(int i=1;i<=m;i++){
//            dp[i][0]= index;
//            index=index+1;
//
//        }
//
//        for(int i=1;i<=m;i++){
//            for(int j=1;j<=n;j++){
//                if(word1.charAt(j-1)==word2.charAt(i-1)){
//                 dp[i][j]= dp[i-1][j-1];
//                }else{
//                    dp[i][j]= Math.min(dp[i-1][j-1],Math.min(dp[i-1][j],dp[i][j-1]))+1;
//                }
//
//            }
//        }
//
//
//
//        System.out.println(dp);
//
//        return dp[m-1][n-1];
//    }
//
//
//
//
//
//
//
//    public static int minPathSum(int[][] grid) {
//
//
//
//        int m = grid.length;
//        int n = grid[0].length;
//
//
//        if(m==1 && n==1){
//            return grid[0][0];
//        }
//
//        int[] [] dp= new int[m][n];
//
//
//        int initial = grid[0][0];
//
//        for(int i=1;i<grid[0].length;i++){
//            dp[0][i]=initial+grid[0][i];
//            initial=dp[0][i];
//
//        }
//
//        if(m==1 && n>1){
//            return initial;
//        }
//
//        initial = grid[0][0];
//
//        for(int i=1;i<grid.length;i++){
//            dp[i][0]=initial+grid[i][0];
//            initial=dp[i][0];
//
//        }
//
//        if(grid.length>1){
//
//
//            for(int i=1;i<m;i++){
//                for(int j=1;j<n;j++ ){
//
//                    dp[i][j]= Math.min(dp[i-1][j],dp[i][j-1]) + grid[i][j];
//                }
//
//
//            }
//
//
//        }
//        return dp[m-1][n-1];
//    }
//
//
//
//
//    public static int uniquePathsWithObstacles(int[][] a) {
//      int m=a.length;
//      int n =a[0].length;
//
//        if(m==1 && n==1){
//            return 1;
//        }
//        int[][] dp = new int[m][n];
//        dp[0][0]=a[0][0];
//
//        for(int i=1;i<n;i++){
//
//            if(a[0][i]==1){
//                break;
//            }
//            dp[0][i]=1;
//
//        }
//
//        for(int i=1;i<m;i++){
//
//            if(a[i][0]==1){
//                break;
//            }
//
//            dp[i][0]=1;
//
//        }
//
//        for(int i=1;i<m;i++){
//            for(int j=1;j<n;j++){
//
//                if(a[i][j]==1){
//                    dp[i][j]=0;
//                  continue;
//                }
//
//                dp[i][j]=dp[i-1][j]+dp[i][j-1];
//
//            }
//        }
//
//        return dp[m-1][n-1];
//
//
//    }
//
//    public static boolean hasSameElementRow(int[][] matrix) {
//        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
//            return false;
//        }
//
//        for (int i = 0; i < matrix.length; i++) {
//            Set<Integer> uniqueElements = new HashSet<>();
//            for (int j = 0; j < matrix[i].length; j++) {
//                uniqueElements.add(matrix[i][j]);
//            }
//            if (uniqueElements.size() == 1) {
//                return true;
//            }
//        }
//
//        return false;
//    }
//
//    public static boolean hasSameElementColumn(int[][] matrix) {
//        if (matrix == null || matrix.length == 0 || matrix[0].length == 0) {
//            return false;
//        }
//
//        for (int j = 0; j < matrix[0].length; j++) {
//            Set<Integer> uniqueElements = new HashSet<>();
//            for (int i = 0; i < matrix.length; i++) {
//                uniqueElements.add(matrix[i][j]);
//            }
//            if (uniqueElements.size() == 1) {
//                return true;
//            }
//        }
//
//        return false;
//    }
//
//
//
//
//
//
//
//
//
//
//
//    public static int uniquePaths(int m, int n) {
//
//        int[][] dp = new int[m][n];
//        dp[0][0]=0;
//
//        for(int i=1;i<n;i++){
//            dp[0][i]=1;
//
//        }
//
//        for(int i=1;i<m;i++){
//            dp[i][0]=1;
//
//        }
//
//        for(int i=1;i<m;i++){
//             for(int j=1;j<n;j++){
//
//                 dp[i][j]=dp[i-1][j]+dp[i][j-1];
//
//             }
//        }
//
//        return dp[m-1][n-1];
//
//    }
//
//
//
//
//
//
//
//
//    public static int[] searchRange(int[] a, int target) {
//
//        int[] arr = new int[2];
//      int y =  getFirst(a, target);
//       int z= getLast(a, target);
//
//       arr[0]=y;
//       arr[1]=z;
//
//       return arr;
//
//
//    }
//
//    private static int getLast(int[] a, int target) {
//        int high = a.length - 1;
//        int low = 0;
//        int res = 0;
//
//        while (low <= high) {
//
//            int mid = (low + high) / 2;
//            if (a[mid] < target) {
//                low = mid + 1;
//
//            }
//            if (a[mid] > target) {
//                high = mid - 1;
//            }
//            if (a[mid] == target) {
//                res = mid;
//                low=mid+1;
//
//            }
//
//        }
//        return res;
//
//    }
//
//
//    private static int getFirst(int[] a, int target) {
//        int high = a.length-1;
//        int low =0;
//        int res =0;
//
//        while (low<=high) {
//
//            int mid = (low + high) / 2;
//            if (a[mid] < target) {
//                low = mid + 1;
//            }
//            if (a[mid] > target) {
//
//                high = mid - 1;
//            }
//            if (a[mid] == target) {
//                res = mid;
//                high = mid - 1;
//            }
//
//        }
//        return res;
//    }
//
//
//}