package org.example;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

class MinStack {

    List<Integer> list;

    List<Integer> min;


    public MinStack() {

        list = new ArrayList<>();
        min=new ArrayList<>();

    }

    public void push(int val) {

        //min = Math.min(val, min);
        list.add(val);

        if (min.isEmpty() || val <= min.get(min.size() - 1)) {
            min.add(val);
        }
    }


    public void pop() {

       int val = list.remove(list.size() - 1);

       if(val==min.get(min.size()-1)){
           min.get(min.size()-1);
       }

    }

    public int top() {

        return list.get(list.size() - 1);
    }

    public int getMin() {
        return min.get(min.size()-1);
    }


    public static void main(String[] args) {
        MinStack minStack = new MinStack();
        minStack.push(512);
        minStack.push(-1024);
        minStack.push(-1024);
        minStack.push(512);
        minStack.pop();
        minStack.getMin(); // return -3
        minStack.pop();
        minStack.getMin(); // return -3
        minStack.pop();
        minStack.getMin();
        System.out.println(minStack.list);// return -3


    }
//["MinStack","push","push","push","push","getMin","pop","getMin","pop","getMin","pop","getMin"]
    // [[],[2],[0],[3],[0],[],[],[],[],[],[],[]]
}