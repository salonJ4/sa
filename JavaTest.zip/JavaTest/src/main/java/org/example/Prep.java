package org.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Prep {

    //String str = "For each country, find the item that has been " ;

    public static void main(String[] args) {
        getRes("For each country, find the item that has been ");


    }

  static void  getRes(String s){


        s=s.replaceAll(" ","");
      HashMap<Character,Integer> hashMap = new HashMap<>();

        for(int i=0;i<s.length();i++){
            hashMap.put(s.charAt(i),hashMap.getOrDefault(s.charAt(i),0)+1);

        }

        List<Integer> indexes = new ArrayList<>();

      List<Integer> list= hashMap.values().stream().sorted(Integer::compareTo).collect(Collectors.toList());
      indexes.add(list.get(list.size()-1));
     indexes.add(list.get(list.size()-2));
     int index=0;
     StringBuilder stringBuilder = new StringBuilder();



      Object c=null;
      for(Map.Entry h:hashMap.entrySet()){

          if(h.getValue()==indexes.get(index)){
              stringBuilder.append(h.getValue());
              c = h.getKey();
              stringBuilder.append("---");
             stringBuilder.append(c);
              System.out.println(stringBuilder.toString());
              stringBuilder= new StringBuilder();

             index=index+1;

             if(index==indexes.size()){
                break;
             }
          }


      }

      System.out.println(hashMap);



    }




}
