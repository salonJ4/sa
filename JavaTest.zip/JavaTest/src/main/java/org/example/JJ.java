package org.example;

import java.util.Arrays;
import java.util.List;

class Minimum{

    // Function which returns minimum sum of two
    // array elements such that their indexes are
    // not same
    public static int minSum(List<Integer> a, List<Integer> b, int n)
    {
        // Finding minimum element in array A and
        // also/ storing its index value.
        int minA = a.get(0), indexA = 0;
        for (int i=1; i<n; i++)
        {
            if (a.get(i) > minA)
            {
                minA = a.get(i);
                indexA = i;
            }
        }

        // Finding minimum element in array B and
        // also storing its index value
        int minB = b.get(0), indexB = 0;
        for (int i=1; i<n; i++)
        {
            if (b.get(i) > minB)
            {
                minB = b.get(i);
                indexB = i;
            }
        }

        // If indexes of minimum elements are
        // not same, return their sum.
        if (indexA != indexB)
            return (minA + minB);

        // When index of A is not same as previous
        // and value is also less than other minimum
        // Store new minimum and store its index
        int minA2 = Integer.MAX_VALUE, indexA2 = 0;
        for (int i=0; i<n; i++)
        {
            if (i != indexA && a.get(i) < minA2)
            {
                minA2 = a.get(i);
                indexA2 = i;
            }
        }

        // When index of B is not same as previous
        // and value is also less than other minimum.
        // Store new minimum and store its index
        int minB2 = Integer.MAX_VALUE, indexB2 = 0;
        for (int i=0; i<n; i++)
        {
            if (i != indexB && b.get(i) < minB2)
            {
                minB2 =b.get(i);
                indexB2 = i;
            }
        }


        return Math.min(minB + minA2, minA + minB2);
    }

    public static void main(String[] args)
    {
        System.out.println("hi");
        List<Integer> a = Arrays.asList(10,2,4);
        List<Integer> b = Arrays.asList(1,9,6);
        int n = 5;
        System.out.print(minSum(a, b, 3));
    }
}