package org.example;

 class Animal {

     protected static Object print(){
         System.out.println("generic");
         return null;
     }
}

class Dog extends Animal {

     public static Integer print() {
        System.out.println("Dog");
        return 1;
    }
}
class Tester{

    public static void main(String[] args) {

        Dog animal = new Dog();
        animal.print();

    }

}

