package org.example;


import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
//from  ww  w  . ja v a2s. c o m

@Retention(RetentionPolicy.RUNTIME)
@interface MyMarker {
}

 class Main {
    @MyMarker
    public static void myMethod() throws Exception{
        Main ob = new Main();
        Method m = ob.getClass().getMethod("myMethod");
        if (m.isAnnotationPresent(MyMarker.class)){
            System.out.println("MyMarker is present.");
        }
    }
    public static void main(String args[]) throws Exception{
       // myMethod();

    }
}

class A{

    static void Jh(){
        System.out.println("hii");
    }

}
class B extends A{
    static void Jh(){
        System.out.println("bii");
    }


}
class Test{
    public static void main(String[] args) {

      //  B.Jh();
        //A.Jh();
        int[] a={0,2,3,4,6,8,9};
        //removeDuplicates(a);
       // longestSubArraySum(a,7);
        summaryRanges(a);
    }



    public static List<String> summaryRanges(int[] nums) {

        List<String> list = new ArrayList<>();
        int last =0;

        for(int i=0;i<nums.length;i++){

            if(i==nums.length-1){
                list.add(String.valueOf(nums[nums.length-1]));
                break;

            }

            if(nums[i]+1!=nums[i+1]){
                list.add(Integer.toString(nums[i]));


            }

            else {
                StringBuilder stringBuilder = new StringBuilder();
                int initial = nums[i];

                while (nums[i]+1==nums[i+1]){
                    last=nums[i+1];

                    if(last==nums[nums.length-1]){
                        break;
                    }

                    if(i<nums.length-1)
                    i=i+1;
                }
                stringBuilder.append(initial);
                stringBuilder.append("->");
                stringBuilder.append(last);
                list.add(stringBuilder.toString());

            }

            if(last==nums[nums.length-1]){
                break;
            }
        }

        return list;

    }













    public static int longestSubArraySum(int[] a, int target) {

        List<Integer> list = new ArrayList<>();
        int left = 0;
        int right = 0;
        int sum = 0;

        if (a.length == 1) {
            return a[0];
        }

        while (right <= a.length) {

            if (sum < target) {

                sum = sum + a[right];
                right = right + 1;


            } else {

                System.out.println("IN ELSE");
                list.add(right - left);

                sum = sum - a[left];
                left = left + 1;

                if (right < a.length) {
                    sum = sum + a[right];
                }

                right = right + 1;

            }
        }

        System.out.println(list);


        if (right > a.length) {

            while (left < right-1) {
                if (sum > target) {
                    list.add(right - left);
                    left = left + 1;
                }

            }

        }

        System.out.println(list);
        return list.stream().min(Integer::compareTo).get();


    }






    public static int removeDuplicates(int[] a) {

        int shiftCount = 0;
        for (int k = 0; k < a.length; k++) {
            for (int i = 0; i < a.length - 1; i++) {

                if (a[i] == a[i + 1]) {
                    a = shiftElements(a, i + 1);
                    shiftCount = shiftCount + 1;
                }

            }

        }
        HashMap<Integer, Integer> hashMap = new HashMap<>();
        int ans = 0;
        for (int k = 0; k < a.length; k++) {

            if (hashMap.containsKey(a[k])) {
                ans = k;
                break;
            } else {
                hashMap.put(a[k], k);
                ans = ans+1;
            }

        }
        System.out.println(ans);
        return ans;
    }

    private static int[] shiftElements(int[] a, int i) {

        int x=a[i];
        for(int j=i;j<a.length-1;j++){
            a[j]=a[j+1];
        }

        a[a.length-1]=x;
        return a;
    }


}


