package org.example;

import java.util.HashMap;
import java.util.Stack;

public class TestJ {

    public static void main(String[] args) {


        //   ybthyyyy
        removeDuplicates("yfttttfbbbbnnnnffbgffffgbbbbgssssgthyyyy",4);

    }

    public static String removeDuplicates(String s, int k) {
        System.out.println(";");
        HashMap<Character,Integer> hashMap =new HashMap<>();
        Stack<Character> stack = new Stack<>();

        for(int i=0;i<s.length();i++){

            char current = s.charAt(i);
            hashMap.put(current,hashMap.getOrDefault(current,0)+1);
            stack.push(current);

            if(hashMap.get(current)>=k && stack.peek()==current){
              stack =   deleteKElements(stack,k);

              if(hashMap.get(current)>=k) {
                  hashMap.remove(current);
              }


            }

        }


        System.out.println(stack);

        int stackSize = stack.size();
        StringBuilder stringBuilder = new StringBuilder();
        for(int i=0;i<stackSize;i++){
            stringBuilder.append(stack.pop());
        }


       stringBuilder= stringBuilder.reverse();
        return stringBuilder.toString();
    }

    private static Stack<Character> deleteKElements(Stack<Character> stack, int k) {

      //  Boolean flag = areLastKElemsSame(stack, k);
        //if (flag) {
            while (k > 0) {
                stack.pop();
                k = k - 1;
            }

      //  }
        return stack;
    }


    private static boolean areLastKElemsSame(Stack<Character> stack, int k) {

        Stack<Character> destinationStack = new Stack<>();
        destinationStack.addAll(stack);
        if (destinationStack.size() < k) {
            return false; // Not enough elements in the stack
        }

        char elemToCompare = destinationStack.pop();
        for (int i = 1; i < k; i++) {
            char nextElem = destinationStack.pop();
            if (nextElem != elemToCompare) {
                // Restore the stack
                stack.push(nextElem);
                for (int j = 0; j < i; j++) {
                    stack.push(elemToCompare);
                }
                return false;
            }
        }

        // Restore the stack
        stack.push(elemToCompare);
        return true;
    }

}
