package org.example;

import java.util.HashMap;
import java.util.LinkedList;

public class LRUCacheImpl {
    // Hash map to store the cache data
    // key as Integer and Value as String
    HashMap<Integer, String> data = new HashMap<Integer, String>();
    // Linked list to store the order of cache access
    LinkedList<Integer> order = new LinkedList<Integer>();
    // size of the cache
    int capacity;

    LRUCacheImpl(int capacity) {
        this.capacity = capacity; // assigning the size of the cache while creating
    }


    void put(int key, String val) {
        if(!data.containsKey(key) && data.size()<capacity){
            order.addLast(key);
            data.put(key,val);
        }
        else {

            int removed = 0;

            if(order.size()>=1 && order.size()==capacity) {

                order.removeFirst();
                data.remove( key);
                order.addLast(key);
               data.put(key,val);
                return;
            }


            order.addLast(key);
            data.put(key,val);


        }

    }

    String get(int key) {
        if(!data.containsKey(key)){
            return "-1";
        }

        order.remove((Object) key);
        order.addLast(key);

        return data.get(key);

    }


    public void display() {

        for (int i = 0; i < order.size(); i++) {
            int key = order.get(i);
            System.out.println(key + " => " + data.get(key));
        }
    }


    public static void main(String[] args) {
        LRUCacheImpl cache = new LRUCacheImpl(3);
        cache.put(1, "one");
        cache.put(2, "two");
        cache.put(3, "three");
        cache.put(4, "four");
        cache.get(3);
        cache.get(2);
        cache.put(1, "one");
        cache.get(3);
        cache.get(1);
        cache.display();
        /*
         * output
         * 1 => one
         * 3 => three
         * 2 => two
         *
         **/
    }

}

