package org.example;

import java.util.*;

class Singleton {

    private static Singleton singleton;


    private Singleton() {

    }

    public void printStatement(){
        System.out.println("printing ---  ");
    }


    public static Singleton singletonMethod() {
        singleton = new Singleton();
        return singleton;
    }


    public static void main(String[] args) {

        ArrayList<Integer> numbers = new ArrayList<>();
        numbers.add(10);

                Iterator<Integer> iterator = numbers.iterator();
        while (iterator.hasNext()) {
            Integer number = iterator.next();
            numbers.add(50);
        }




       /* System.out.println("print");
        Singleton singleton= Singleton.singletonMethod();
        singleton.printStatement();

        Set<Integer> set = new HashSet<>();
        LinkedList<Integer> h = new LinkedList<>();
        h.add(4);
        System.out.println(h.get(0));*/
    }
}

class Demo{
    public static void main(String[] args) {






    }


}