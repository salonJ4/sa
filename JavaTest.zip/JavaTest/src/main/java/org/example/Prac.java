package org.example;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Prac {

    public static void main(String[] args) {


        int[][] matrix = {
                {0, 1, 0},
                {0, 0, 1},
                {1, 1, 1},
                {0, 0, 0}
        };

        gameOfLife(matrix);
    }


    public static void gameOfLife(int[][] board) {


        int[][] destinationArray = Arrays.stream(board)
                .map(int[]::clone)
                .toArray(int[][]::new);

        int current = 0;
        int countOne = 0;
        int rowMax = board.length - 1;
        int colMax = board[0].length - 1;


        for (int i = 0; i < board.length; i++) {

            for (int j = 0; j < board[0].length; j++) {

                current = destinationArray[i][j];

                if (j < colMax) {
                    countOne = destinationArray[i][j + 1] + countOne;
                }
                if (j > 0) {
                    countOne = destinationArray[i][j - 1] + countOne;
                }

                if (i < rowMax) {
                    countOne = destinationArray[i + 1][j] + countOne;
                }
                if (i > 0) {
                    countOne = destinationArray[i - 1][j] + countOne;
                }

                if (i < rowMax && j > 0) {
                    countOne = destinationArray[i + 1][j - 1] + countOne;
                }

                if (i < rowMax && j < colMax) {
                    countOne = destinationArray[i + 1][j + 1] + countOne;
                }
                if (i > 0 && j > 0) {
                    countOne = destinationArray[i - 1][j - 1] + countOne;
                }

                if (i > 0 && j < colMax) {
                    countOne = destinationArray[i - 1][j + 1] + countOne;
                }


                if (current == 1) {
                    if (countOne < 2) {

                        board[i][j] = 0;


                    } else if (countOne > 3) {
                        board[i][j] = 0;
                    }


                } else {

                    if (countOne == 3) {
                        board[i][j] = 1;
                    }
                }

                countOne = 0;
            }

        }
    }


    public static void setZeroes(int[][] matrix) {


        boolean[][] boolArray = new boolean[matrix.length][matrix[0].length];

        for (int i = 0; i < matrix.length; i++) {

            for (int j = 0; j < matrix[0].length; j++) {

                if (matrix[i][j] == 0) {

                    boolArray[i][j] = true;
                    setEntireRowToMinusOne(i, boolArray, matrix);
                    setEntireColumnToMinusOne(j, boolArray, matrix);


                }

            }

        }


    }

    private static void setEntireColumnToMinusOne(int j, boolean[][] matrix, int[][] ints) {
        for (int i = 0; i < matrix.length; i++) {
            if (matrix[i][j] != true && ints[i][j] != 0) {
                matrix[i][j] = true;
            }
        }

    }

    private static void setEntireRowToMinusOne(int i, boolean[][]
            matrix, int[][] ints) {
        for (int j = 0; j < matrix[0].length; j++) {
            if (matrix[i][j] != true && ints[i][j] != 0) {
                matrix[i][j] = true;
            }

        }
    }


}
