package org.example;

class Node5 {
    int data;
    Node5 next;

    public Node5(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node5 head;

    public LinkedList() {
        this.head = null;
    }

    public void insertAtEnd(int data) {
        Node5 newNode = new Node5(data);

        if (head == null) {
            head = newNode;
            return;
        }

        Node5 current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    public void display() {
        Node5 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }


    public static Node5 rotateRight(Node5 head, int k) {


        Node5 temp = head;
        Node5 temp2 = temp;
        Node5 temp3 = temp2;
        int count = 0;
        while (head != null) {
            count = count + 1;
            head = head.next;
        }



        if(k>count){
            k=k%count;
        }

        int loopCount = count - k;
        for (int i = 0; i < loopCount; i++) {
            temp = temp.next;
            if (i < loopCount - 1)
                temp2 = temp2.next;
        }
        temp2.next = null;


        Node5 res = temp;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = temp3;

        return res;
    }


    public static Node5 rotateRight2(Node5 head, int k) {


        Node5 res = head;
        for(int i=0;i<k;i++) {


             res = rotateOnce(res);
        }


        return res;


    }

    private static Node5 rotateOnce(Node5 head) {


        Node5 temp2 = head;
        Node5 temp3 = temp2;

        while (head.next!=null){
            head=head.next;
        }
       while (temp2.next.next!=null){
           temp2=temp2.next;
       }
       temp2.next=null;
       head.next=temp3;

       return head;

    }
}


 class Main4 {
    public static void main(String[] args) {
        LinkedList ll = new LinkedList();
        ll.insertAtEnd(1);
        ll.insertAtEnd(2);
        //ll.insertAtEnd(2);
       // ll.insertAtEnd(4);
        //ll.insertAtEnd(5);
      //  ll.insertAtEnd(6);

        ll.display();
       Node5 x= LinkedList.rotateRight(ll.head,2);
        System.out.println(x);

       // LinkedList.rotateRight2(ll.head,4);


    }
}