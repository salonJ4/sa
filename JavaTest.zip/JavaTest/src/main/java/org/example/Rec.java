package org.example;

public class Rec {
    public static void main(String[] args) {

     boolean b =   isPowerOfFour(256);
        System.out.println(b);
    }

    public static boolean isPowerOfFour(int n) {

        boolean flag = false;


        if(n==1){
            flag=true;
            return true;
       }

        if(n%4!=0){
            return false;
        }

       return isPowerOfFour(n/4);

    }
}
