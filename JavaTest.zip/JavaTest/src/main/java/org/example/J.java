/*
package org.example;

import java.util.Collections;
import java.util.List;



class Department{

        int id;
      List<Emp> empList;

    }

class Emp{
        int id;
        int age;


}




















    public static int divide(int dividend, int divisor) {


        // 2 bit left shift operation
        //    int Ans = number << 1;
        // System.out.println(Ans);

        if(dividend==Integer.MAX_VALUE && divisor==1){
            return Integer.MAX_VALUE;
        }

        if(dividend<=Integer.MIN_VALUE){
            dividend=Integer.MIN_VALUE-1;
            if(divisor==1){
                return Integer.MIN_VALUE-1;
            }
            else {
                return Integer.MAX_VALUE;
            }
        }



        boolean isNegative = (dividend < 0 && divisor > 0) || (dividend > 0 && divisor < 0) ? true : false;
        divisor = Math.abs(divisor);
        dividend=Math.abs(dividend);

        if(dividend==0 || dividend<divisor){
            return 0;
        }


        dividend = Math.abs(dividend);
        divisor = Math.abs(divisor);
        int count = 1;
        int x=divisor<<1;
        int y=0;


        while (x<dividend){
            count=count+1;
            y=x;
            x = x<<1;

        }



        int z=divisor;
        while ((z<(dividend-y))){
            z=z<<1;
            count=count+1;
        }



        if(isNegative){
            count=count*-1;
        }
        System.out.println(count);
        return count;
    }
}
*/
