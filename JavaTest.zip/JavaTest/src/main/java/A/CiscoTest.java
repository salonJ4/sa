package A;

import java.util.*;

import static java.util.stream.Collectors.toList;

public class CiscoTest {



    public static void main(String[] args) {


        int[] x={5,4,8,7,10,2};
      int y=  minimumSum(x);
        System.out.println(y);
    }

    public static int minimumSum(int[] nums) {

        int ans = Integer.MAX_VALUE;
        int currSum =0;
        int[] prefixSmaller = new int[nums.length];
        prefixSmaller[0]=nums[0];

        int[] suffixSmaller = new int[nums.length];
        suffixSmaller[suffixSmaller.length-1]=nums[nums.length-1];

        for(int i=1;i<nums.length;i++){

            int current = nums[i];
           if(prefixSmaller[i-1]<current){
               prefixSmaller[i]=prefixSmaller[i-1];
           }
           else {
               prefixSmaller[i]=current;
           }
        }

        for(int i=1;i<nums.length;i++){

            int current = nums[i];
            if(prefixSmaller[i-1]<current){
                prefixSmaller[i]=prefixSmaller[i-1];
            }
            else {
                prefixSmaller[i]=current;
            }
        }

        for(int i=nums.length-2;i>=0;i--){

            int current = nums[i];
            if(suffixSmaller[i+1]<current){
                suffixSmaller[i]=suffixSmaller[i+1];
            }
            else {
                suffixSmaller[i]=current;
            }
        }

        for(int i=0;i<nums.length;i++){
            int current = nums[i];

            if(prefixSmaller[i]<current && suffixSmaller[i]<current){
                currSum=current+prefixSmaller[i]+suffixSmaller[i];
                ans = Math.min(currSum,ans);
            }



        }
        return ans;

    }











    public  static int minOperations(int[][] grid, int x) {

        if (grid.length == 1) {

            if (grid[0][0] % x == 0) {
                return grid[0][0] / x;
            } else {
                return -1;
            }

        }


        int[] arr = new int[grid.length * grid[0].length];
        int count = arr.length - 1;
        for (int i = 0; i < grid.length; i++) {
            for (int j = 0; j < grid[0].length; j++) {
                arr[count] = grid[i][j];
                count = count - 1;
            }

        }

        Arrays.sort(arr);

        int target = arr[(arr.length - 1) / 2];
        int indiceOneCount = 0;


        for (int i = 0; i < arr.length; i++) {
            int curr = arr[i];



                while (curr > target) {
                    curr = curr - x;
                    indiceOneCount = indiceOneCount + 1;
                }
                while (curr < target) {
                    curr = curr + x;
                    indiceOneCount = indiceOneCount + 1;
                }

            if (Math.abs(curr - target) % x != 0) {
                return -1;
            }



        }
        return indiceOneCount;
    }







    public static int findMinFibonacciNumbers(int k) {



        int count =0;
        while (k>=1) {

            int first = 1;
            int second = 1;
            int third = first+second;


            while (third <= k) {

                first = second;
                second = third;
                third = first + second;


            }

            k = k - second;
            count = count+1;

        }

        return count;
    }









    private static List<Integer> executeForPositiveK(int[] code, int k) {

        List<Integer> list = new ArrayList<>();
        int left = 0;
        int right = 0;
        int currentWindowSum = 0;

        for(int i=1;i<k+1;i++){
            currentWindowSum = currentWindowSum+code[i];
        }

        list.add(currentWindowSum);

        for (int i = 1; i < code.length; i++) {

            int curr = code[i];

            left = i + 1;
            right=left+k-1;

            if(left>=code.length) {
                left= Math.abs(code.length-left);
            }

            if(right>=code.length) {
                right= Math.abs(code.length-right);
            }

            int x=code[left];
            int y=code[right];

            currentWindowSum =  currentWindowSum-curr+code[right];
            list.add(currentWindowSum);

        }

        return list;

    }

    private static List<Integer> executeForNegativeK(int[] code, int k) {

       List<Integer> list = new ArrayList<>();
        int left = 0;
        int right = code.length-2;
        int currentWindowSum = 0;
        int kPos = Math.abs(k);
        for(int i=0;i<kPos;i++){

            currentWindowSum = currentWindowSum+code[right];
            right=right-1;

        }

        list.add(currentWindowSum);
        right=code.length-2;

        for(int i = right;i>=0;i-- ){

            int curr = code[i];
            right=i-1;
            left=right+k+1;

            if(left<0){
                left=code.length-Math.abs(left);
            }

            currentWindowSum = currentWindowSum-curr+code[left];
            list.add(currentWindowSum);

        }

        Collections.reverse(list);
        return list;


    }

    private static List<Integer> executeForZeroK(int[] code, int k){
        List<Integer> list = new ArrayList<>();
        for(int i=0;i<code.length;i++){
            list.add(0);
        }
        return list;
    }




    public static int longestSquareStreak(int[] nums) {
        int max=0;

        Set<Long> set = new HashSet();
        for(int num : nums){
            set.add((long)num);
        }

        for(int i=0;i<nums.length;i++){


            long curr = nums[i];
            int count =1;

            while (set.contains(curr*curr)) {

                count = count + 1;
                curr = curr * curr;
            }

            max = Math.max(max,count);

        }


        return  max;
    }



    public static int distinctPrimeFactors(int[] nums) {


       int maxNumber = Arrays.stream(nums).max().getAsInt();
      List<Integer> list = primeNumberTillN(maxNumber);

      HashSet<Integer> integers = new HashSet<>();

      for(int i=0;i<nums.length;i++){

          int current = nums[i];

          for(Integer x:list){

              if(current%x==0){
                  integers.add(x);
              }

              if(x>=current){
                  break;
              }


          }


      }

        System.out.println(integers.size());
      return integers.size();

    }

    private static List<Integer> primeNumberTillN(int maxNumber) {

        List<Integer> list = new ArrayList<>();
        for(int i=2;i<=maxNumber;i++){

            if(isPrime(i)){

                list.add(i);
            }


        }

        return list;


    }

    private static boolean isPrime(int n) {

        for(int i=2;i<n;i++){

            if(n%i==0){
                return false;
            }


        }

        return true;
    }


    public static boolean digitCount(String num) {

        if(num.length()==1){
            return true;
        }

        HashMap<Integer,Integer> hashMap = new HashMap<>();


        for(int i=0;i<num.length();i++){
            int curr = Character.getNumericValue(num.charAt(i));

            hashMap.put(curr,hashMap.getOrDefault(curr,0)+1);

        }

        boolean test=false;

        for(int i=0;i<num.length();i++){

            int curr = Character.getNumericValue(num.charAt(i));

            if(hashMap.get(i)==null && curr==0){
                test=true;
                continue;
            }

            if(hashMap.get(i)!=null){
            if(curr==hashMap.get(i)){
                test=true;
            }
            else {
                test=false;
                break;
            }



        }}

        return test;
    }








    public static int maxUncrossedLines(int[] nums1, int[] nums2) {

        int[][] dp = new int[nums1.length+1][nums2.length+1];

        for(int i=1;i<dp.length;i++){

            for(int j=1;j<dp[0].length;j++){

                if(nums1[i-1]==nums2[j-1]){

                    dp[i][j]=1+dp[i-1][j-1];
                }
                else {

                    dp[i][j]= Math.max(dp[i-1][j],dp[i][j-1]);
                }

            }


        }
        return dp[nums1.length][nums2.length];
    }



    public static int maxSum(int[][] a) {

        int maxSum =0;

        for(int i=0;i<a.length-2;i++) {
            for (int j = 0; j < a[0].length-2; j++) {
              int  currSum = a[i][j] + a[i][j + 1] + a[i][j + 2] + a[i + 1][j + 1] + a[i + 2][j] + a[i + 2][j + 1] + a[i + 2][j + 2];
              maxSum=Math.max(currSum,maxSum);


            }
        }

        System.out.println(maxSum);
        return maxSum;
    }



    public static boolean hasAllCodes(String s, int k) {
        int maxNumberOfStrings = (int)Math.pow(2,k);
        HashSet<String> strings = new HashSet<>();

        for(int i=0;i<s.length()-k+1;i++){
            String current = s.substring(i,i+k);
            strings.add(current);

        }
        if(strings.size()==maxNumberOfStrings){
            return  true;
        }
        else{
            return false;
        }

    }







    public static int[][] generateMatrix(int n) {

        int[][] arr=new int[n][n];
         int count =1;
        
        int istart = 0;
        int jstart =0;
        int imax=n-1;
        int jmax=n-1;
        int limit =0;


        if(n%2==0){
            limit=n/2;
        }
        else {
            limit=n/2+1;
        }


        for(int i=0;i<limit;i++) {

           count= printleftToRight(istart, jstart, imax, jmax,n,count,arr);
            istart = istart + 1;

            count=printTopToBottom(istart, jstart, imax, jmax,n,count,arr);
            jmax = jmax - 1;


           count= printRightToLeft(istart, jstart, imax, jmax,n,count,arr);
            imax = imax - 1;

           count= printBottomToTop(istart, jstart, imax, jmax,n,count,arr);
            jstart=jstart+1;

        }


        System.out.println(arr);
        return null;
        }

    private static int printBottomToTop(int istart, int jstart, int imax, int jmax, int n, int count, int[][] arr) {
        for(int i=imax;i>=istart;i--){

            if(count>n*n){
                break;
            }
            arr[i][jstart]=count;

            count=count+1;
        }
        return count;
    }

    private static int printRightToLeft(int istart, int jstart, int imax, int jmax, int n, int count, int[][] arr) {

        for(int j=jmax;j>=jstart;j--){

            if(count>n*n){
                break;
            }
            arr[imax][j]=count;

            count=count+1;
        }
        return count;
    }

    private static int printTopToBottom(int istart, int jstart, int imax, int jmax, int n, int count, int[][] arr) {
        for(int i=istart;i<=imax;i++){

            if(count>n*n){
                break;
            }

            arr[i][jmax]=count;

            count=count+1;
        }

        return count;
    }

    private static int printleftToRight(int istart, int jstart, int imax, int jmax, int n, int count, int[][] arr) {
        for(int j=jstart;j<=jmax;j++){


            if(count>n*n){
                break;
            }
            arr[istart][j]=count;

            count=count+1;
        }
        return count;
    }


}


final class Emp{
  private final String name;

    Emp(String name) {
        this.name = name;
    }

    public static void main(String[] args) {
        Emp e = new Emp("hh");

    }
}

abstract class g{

    abstract void print();

   abstract void p();


}

// Interfaces Declared
interface Parent1 {
    void fun();
}


interface Parent2 {
    void fun();
}

// Inheritance using Interfaces
class test implements Parent1, Parent2 {
    public void fun()
    {
        System.out.println("fun function");
    }
}

// Driver Class
class test1 {
    // main function
    public static void main(String[] args)
    {
        test t = new test();
        t.fun();
    }
}