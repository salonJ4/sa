package A;

// Java program to merge two sorted
// linked lists in-place.
class GfG {

    static class Node {
        int data;
        Node next;
    }

    // Function to create newNode in a linkedlist
    static Node newNode(int key)
    {
        Node temp = new Node();
        temp.data = key;
        temp.next = null;
        return temp;
    }

    // A utility function to print linked list
    static void printList(Node node)
    {
        while (node != null) {
            System.out.print(node.data + " ");
            node = node.next;
        }
    }



    // Merges two given lists in-place. This function
    // mainly compares head nodes and calls mergeUtil()
    static Node merge(Node head1, Node head2)
    {

        Node t1 = head1;
        Node t2 = head2;

        Node dummy = newNode(-1);
        Node temp = dummy;


        while (t1!=null && t2!=null) {
            if (t1.data <= t2.data) {

                temp.next = t1;
                t1 = t1.next;
                temp=temp.next;

            } else {
                temp.next = t2;
                t2 = t2.next;
                temp=temp.next;
            }
        }

        if(t1!=null){
            temp.next=t1;
            t1=t1.next;
        }

        if(t2!=null){
            temp.next=t2;
            t2=t2.next;
        }


        return  null;
    }

    // Driver code
    public static void main(String[] args)
    {
        Node head1 = newNode(2);
        head1.next = newNode(3);
        head1.next.next = newNode(5);

        // 1->3->5 LinkedList created

        Node head2 = newNode(0);
        head2.next = newNode(1);
        head2.next.next = newNode(4);
        head2.next.next.next=newNode(6);

        // 0->2->4 LinkedList created

        Node mergedhead = merge(head1, head2);

       // printList(mergedhead);
    }
}

// This code is contributed by
// prerna saini
