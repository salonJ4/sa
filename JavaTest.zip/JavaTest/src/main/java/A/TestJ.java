package A;

import org.example.Employee;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

abstract class Shape{
    String color;

    Shape(){

    }

    Shape(String color){
        this.color=color;
        System.out.println(this.color);
    }
}
 class AE extends  Shape{

    AE(String y){
        super(y);
    }
 }

class AF extends  Shape{

    AF(String y){
      //  super(y);
    }
}


class Tester{
    public static void main(String[] args) {
        AE ae = new AE("blue");
        System.out.println(ae.color);
        AF af = new AF("gray");
    }
}

