package A;

import java.util.*;

class CompletableFutureExample {
    public static void main(String[] args) {

        int[] x={4,2,4,5,6};

       int y= maximumUniqueSubarray(x);
        System.out.println(y);

    }




    public  static int maximumUniqueSubarray(int[] nums) {

        int i=0,j=0;

        HashSet<Integer> hashSet = new HashSet<>();
        int currSum =0;
        int max=Integer.MIN_VALUE;


        while (j<nums.length){

            currSum=currSum+nums[j];

            if(hashSet.contains(nums)){

                while (i<=j && hashSet.contains(nums[j])){

                    hashSet.remove(nums[i]);
                    currSum = currSum-nums[i];
                    i=i+1;

                }

            }

            max=Math.max(max,currSum);

            j=j+1;
            hashSet.add(nums[j]);


        }



        return max;


    }




    public static int[] restoreArray(int[][] adjacentPairs) {

        if(adjacentPairs.length==1){
            return adjacentPairs[0];
        }

        int[] ans = new int[adjacentPairs.length + 1];
        int i = 0; // ans' index
        Map<Integer, List<Integer>> numToAdjs = new HashMap<>();

        for (int[] pair : adjacentPairs) {
            numToAdjs.putIfAbsent(pair[0], new ArrayList<>());
            numToAdjs.putIfAbsent(pair[1], new ArrayList<>());
            numToAdjs.get(pair[0]).add(pair[1]);
            numToAdjs.get(pair[1]).add(pair[0]);
        }
        List<Integer> list = new ArrayList<>();


        for(Map.Entry m:numToAdjs.entrySet()) {
            ArrayList x = (ArrayList) m.getValue();
            if (x.size() == 1) {
                list.add((Integer) m.getKey());
                list.add((Integer) x.get(0));
                break;
            }
        }

            int head = list.get(0);
            int tail = list.get(1);

            while (list.size() <= adjacentPairs.length + 1) {

                List<Integer> list1 = numToAdjs.get(tail);

                if (list1.get(0) == head) {
                    list.add(list1.get(1));

                }
                else {
                    list.add(list1.get(0));
                }

                head=tail;
                tail = list.get(list.size() - 1);

                if(list.size()==adjacentPairs.length+1){
                    break;
                }


            }

        int[] array = list.stream().mapToInt(Integer::intValue).toArray();



        return array;
    }
}
