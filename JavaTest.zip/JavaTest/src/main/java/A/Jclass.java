/*
package A;


import java.util.*;
import java.util.stream.Collectors;


public class Jclass {

   static StringBuilder x = new StringBuilder();

    public static void main(String[] args) {
              boolean y =  isInterleave("aa","ab","aaba");
        System.out.println(y);
        }



    public static boolean isInterleave(String s1, String s2, String s3) {
        int x = s1.length();
        int y = s2.length();
        int z = s3.length();

        if(x+y!=z){
            return false;
        }

        if(s1.isEmpty() && s2.isEmpty() && s3.isEmpty()){
            return true;
        }


        if(s1.isEmpty() && s2.isEmpty() && !s3.isEmpty()){
            return false;
        }

        if((s1.isEmpty() || s2.isEmpty()) && !s3.isEmpty()){
            if(s1.isEmpty()) {
                if (s2.equals(s3)) {
                    return true;
                }
                else{
                    return false;
                }
            }
            else{
                if(s1.equals(s3)){
                    return true;
                }
                else {
                    return false;
                }
            }
        }


        if(s1.equals(s3) || (s2.equals(s3)) &&  !s3.isEmpty()){
            return false;
        }




        int firstStrIndex = 0;
        int secondStrIndex = 0;
        int thirdIndex = 0;
        List<Object> list = new ArrayList<>();
        StringBuilder res = new StringBuilder();


        if(s1.charAt(0)==s3.charAt(0) && s3.charAt(0)==s2.charAt(0)){
            res.append(s3.charAt(0));
            thirdIndex=thirdIndex+1;
            firstStrIndex=firstStrIndex+1;
            secondStrIndex=secondStrIndex+1;

            if(s1.charAt(1)==s3.charAt(1)){
                res.append(s3.charAt(thirdIndex));
                thirdIndex=thirdIndex+1;
                firstStrIndex=firstStrIndex+1;
            }
            else {
                res.append(s3.charAt(thirdIndex));
                thirdIndex=thirdIndex+1;
                secondStrIndex=secondStrIndex+1;
            }

        }

        while (thirdIndex < s3.length()) {

            if (s3.charAt(thirdIndex) != s1.charAt(firstStrIndex) &&
                    s3.charAt(thirdIndex) != s2.charAt(secondStrIndex)) {
                return false;
            }

            while (s3.charAt(thirdIndex) == s1.charAt(firstStrIndex)) {
                list = checkSubsequent(s1, s3, firstStrIndex, thirdIndex, res);
                thirdIndex = (int) list.get(0);
                firstStrIndex = (int) list.get(1);

                if (thirdIndex == s3.length()) {
                    if (list.get(2).toString().equals(s3)) {
                        return true;
                    } else {
                        return false;
                    }
                }
            }

            while (s3.charAt(thirdIndex) == s2.charAt(secondStrIndex)) {
                list = checkSubsequent(s2, s3, secondStrIndex, thirdIndex, res);
                thirdIndex = (int) list.get(0);
                secondStrIndex = (int) list.get(1);

                if (thirdIndex == s3.length()) {
                    if (list.get(2).toString().equals(s3)) {
                        return true;
                    } else {
                        return false;
                    }
                }

            }
        }

        return false;
    }

    private static List<Object> checkSubsequent(String s, String s3, int strIndex, int i,StringBuilder sb) {

        List<Object> list = new ArrayList<>();

        while (s3.charAt(i) == s.charAt(strIndex)){
            sb.append(s3.charAt(i));
         i=i+1;
         strIndex=strIndex+1;


            if(strIndex==s.length()){
                strIndex=strIndex-1;
                list= new ArrayList<>();
                list.add(i);
                list.add(strIndex);
                list.add(sb);

               return list;
            }


        }


        list.add(i);
        list.add(strIndex);
        list.add(sb);

      return list;
    }


    public static int minimumIndex(List<Integer> nums) {
        HashMap<Integer,Integer> map = new HashMap<>();
        int ans = -1;
        int dominant = 0;

        for(Integer n:nums){
            map.put(n,map.getOrDefault(n,0)+1);
        }


        for(Map.Entry m: map.entrySet()){
            int val =(int) m.getValue();
            if(val*2>nums.size()){
                dominant = (int) m.getKey();
                }
            }

     Integer dominantFreq =   map.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getValue).get();
     int dominantEncounteredCount = 0;

        for(int i=0;i<nums.size();i++ ){

            if(nums.get(i)==dominant){
                dominantEncounteredCount=dominantEncounteredCount+1;
                dominantFreq = dominantFreq-1;
            }


            int currLength = i+1;
            int remLength = nums.size()-currLength;

            if(dominantEncounteredCount*2>currLength && dominantFreq*2>remLength){
                ans = i;
                return ans;
            }

        }
        return ans;
    }





    public static int numDecodings(String s) {

        if(s.startsWith("0")){
            return 0;
        }

        int dp[] =  new int[s.length()+1];
        dp[0]  = 1;
      dp[1] =   s.charAt(0)!= 0 ? 1 : 0;

      for(int i=2;i<dp.length;i++){

          if(s.charAt(i-1)-'0'>0 && s.charAt(i-1)-'0'<9){
              dp[i]=dp[i-1];
          }

          StringBuilder sb = new StringBuilder();
          sb.append(s.charAt(i-2));
          sb.append(s.charAt(i-1));

          int x= Integer.parseInt(sb.toString());
          sb = new StringBuilder();
          if(x>=10 && x<=26){
              dp[i]=dp[i]+dp[i-2];
          }

      }

      return dp[s.length()];


    }



    public static String maskPII(String s) {
        String ans=null;

        if(Character.isAlphabetic(s.charAt(0))){
           ans = maskMailId(s);
        }
        else{
           ans = maskPhoneNumber(s);
        }

        return ans;

    }

    private static String maskPhoneNumber(String s) {

       List<Character> list = Arrays.asList('+','-','(',')',' ');
       StringBuilder sb = new StringBuilder();
       for(int i=0;i<s.length();i++){
           if(!list.contains(s.charAt(i))){
               sb.append(s.charAt(i));
           }
       }

        StringBuilder res = new StringBuilder();

           res.append("***-***-");
           res.append(sb.toString().substring(6));
           if(sb.length()==10){
               return res.toString();
           }

           else if(sb.length()==11){
              res.insert(0,"+*-");
              return res.toString();
           }

           else if(sb.length()==12){
               res.insert(0,"+**-");
               return res.toString();

           }
           else {
               res.insert(0,"+***-");
               return res.toString();

           }

    }

    private static String maskMailId(String s) {

        String[] x= s.split("@");
        String start = x[0];
        String end = x[1];
        StringBuilder sb = new StringBuilder();
        sb.append(Character.toLowerCase(start.charAt(0)));
        sb.append("*****");
        sb.append(Character.toLowerCase(start.charAt(start.length()-1)));
        sb.append("@");

        sb.append(end.toLowerCase());
        System.out.println(sb.toString());
        return sb.toString();

    }


    public static int[] productExceptSelf(int[] nums) {

        int[] prefix = new int[nums.length];
        int[] suffix = new int[nums.length];

        prefix[0]=1;

        if(nums[0]==0){
            prefix[0]=0;
        }

        suffix[suffix.length-1]=1;

        if(nums[nums.length-1]==0){
            suffix[suffix.length-1]=0;
        }


        int preRes = 1;
        int sufRes = 1;
        int prefixIndex = 1;
        int suffixIndex= suffix.length-2;


        for(int i=0;i<prefix.length-1;i++) {
            prefix[prefixIndex] = nums[prefixIndex - 1] * preRes;
            preRes = prefix[prefixIndex];
            prefixIndex=prefixIndex+1;

            suffix[suffixIndex]=nums[suffixIndex+1]*sufRes;
            sufRes = suffix[suffixIndex];
            suffixIndex=suffixIndex-1;


        }



        for(int i=0;i<nums.length;i++){
            nums[i]=prefix[i]*suffix[i];
        }

        return nums;
    }
}

class Empl{

}
class Tesft{
    public static void main(String[] args) {
        Empl e=new Empl();
        e.getClass().isAnnotationPresent()
    }
}*/
