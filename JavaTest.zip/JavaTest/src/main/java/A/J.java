package A;

import java.util.*;
import java.util.stream.Collectors;

public class J {


    public static void main(String[] args) {
        int[] arr = {1,2,3,1,2,3,1,2};
        int k =2;
     int y=   maxSubarrayLength(arr,k);
        System.out.println(y);
        }


    public static int maxSubarrayLength(int[] nums, int k) {

        HashMap<Integer,Integer> map = new HashMap<>();

        int i=0;
        int j=0;
        int max=0;
        int maxLength=0;


        while (i<=j){



                map.put(nums[j], map.getOrDefault(nums[j], 0) + 1);
                while(map.get(nums[j]) > k) {
                    int left = nums[i];
                    map.put(left, map.get(left) - 1);
                    i =i+ 1;
                  // break;
                }

                maxLength = Math.max(maxLength, j - i + 1);
            j=j+1;
            if(j==nums.length-1){
                return maxLength;
            }
            }



        return max;

    }














    public static int[] constructRectangle(int area) {

        int sr = (int)Math.sqrt(area);
        if(sr*sr==area){

        }
        else{
            int length = sr;
            int breadth = sr;





        }

        return null;
    }




    public static int[] findOriginalArray(int[] changed) {


        Arrays.sort(changed);

        boolean allZeros1 = Arrays.stream(changed).allMatch(i -> i == 0);
        int[] zeroArr=new int[changed.length/2];


        if(allZeros1){

            Arrays.setAll(zeroArr, i -> 0);
            return zeroArr;

        }


        List<Integer> list = new ArrayList<>();

        HashMap<Integer,Integer> map=new HashMap<>();

        for(int i=0;i<changed.length;i++){

            map.put(changed[i],map.getOrDefault(changed[i],0)+1);
        }


        for(int i=0;i<changed.length;i++){

            if(map.get(changed[i])==2){
                map.put(changed[i],0);
                list.add(changed[i]);
                continue;
            }


            if(map.containsKey(changed[i]*2 )){

                int currVal = map.get(changed[i]);
                int doubleVal = map.get(changed[i]*2);

                if(currVal==0 || doubleVal==0){
                    continue;
                }


                currVal=currVal-1;
                doubleVal=doubleVal-1;

                map.put(changed[i],currVal);
                map.put(changed[i]*2,doubleVal);

                list.add(changed[i]);

            }
        }

        int[] array = list.stream().mapToInt(Integer::intValue).toArray();

        if(array.length==changed.length/2){
            return array;
        }
        else{
            return new int[0];
        }

// return array;
    }
}
