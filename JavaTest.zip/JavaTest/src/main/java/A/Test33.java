package A;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Test33 {
    public static void main(String[] args) {

        //find out all the numbers starting with 1 using Stream functions?

      //  10,15,8,49,25,98,32,132;

        List<Integer> list = Arrays.asList(10,15,8,49,25,98,32,132);

       List<Integer> res = list.stream().map(e->String.valueOf(e)).filter(e->e.startsWith("1")).map(s->Integer.parseInt(s)).collect(Collectors.toList());
        System.out.println(res);
    }
}
