package A;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.IntStream;

public class Prac {

    public static void main(String[] args) {

        int[] x={1,5,7,8,5,3,4,2,1};

     int y=   longestSubsequence(x,-2);
        System.out.println(y);
    }




    public  static int longestSubsequence(int[] arr, int difference) {

      int[] dp=new int[arr.length];
      List<Integer> list = new ArrayList<>();
      list.add(arr[0]);

      dp[0]=1;

      for(int i=1;i<arr.length;i++){
          int current = arr[i];
          list.add(current);


          if(list.contains(current-difference)){

              int y=current-difference;
           int lastIndex=   findLastIndex(list,y);
        dp[i]=1+dp[lastIndex];
          }
          else {
              dp[i]=1;
          }

      }

      return   Arrays.stream(dp).max().getAsInt();

    }

    public static int findLastIndex(List<Integer> list, int target) {
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i) == target) {
                return i;
            }
        }
        return -1; // Target not found
    }


    public static long minimumSteps2(String s) {
        long swapCount =0;

        for(int j=0;j<s.length()-1;j++) {
            for (int i = 0; i < s.length() - 1; i++) {

                int first = Character.getNumericValue(s.charAt(i));
                int second = Character.getNumericValue(s.charAt(i + 1));

                if (first == 1 && second == 0) {
                    s = swapCharacters(s, i, i + 1);
                    swapCount = swapCount + 1;
                }

            }
        }
       return swapCount;

    }

    public static long minimumSteps(String s) {

        int left =0;
        int right = s.length()-1;
        long swap=0;

        while (left<right){

            int a = Character.getNumericValue(s.charAt(left));
            int b = Character.getNumericValue(s.charAt(right));

            if(a==1 && b==0){
               s=swapCharacters(s,left,right);
               left=left+1;
               right=right-1;
               swap=swap+1;
            }

            if(a==0 && b==0){
                left=left+1;
            }

            if(a==1 && b==1){
                right=right-1;
            }

        }

        System.out.println(s.length());
        System.out.println(s);
        return swap;


    }

    public static String swapCharacters(String input, int index1, int index2) {
        char[] charArray = input.toCharArray();

        // Check if the indices are within the bounds of the string
        if (index1 < 0 || index1 >= input.length() || index2 < 0 || index2 >= input.length()) {
            throw new IllegalArgumentException("Indices are out of bounds");
        }

        // Swap the characters
        char temp = charArray[index1];
        charArray[index1] = charArray[index2];
        charArray[index2] = temp;

        // Convert the character array back to a string
        return new String(charArray);
    }




    public static int[][] intervalIntersection(int[][] firstList, int[][] secondList) {
        List<int[]> list = new ArrayList<>();

        int i =0;
        int j=0;

        while (i<firstList.length && j<secondList.length){



            int[] first=firstList[i];
            int[] second = secondList[j];



            if(first[1]==second[1]){
                int[] range = new int[2];
                range[1]=first[1];
                if(first[0]>second[0]){
                    range[0]=first[0];
                }
                else {
                    range[0]=second[0];
                }

                list.add(range);

                i=i+1;
                j=j+1;
            }

            else if(first[1]<second[1]){

                int[] range = new int[2];
                range[0]= Math.max(second[0],first[0]);
                range[1]=first[1];
                if(range[0]<=range[1]) {
                    list.add(range);
                }
                i=i+1;

            }

            else if(second[1]<first[1]){

                int[] range = new int[2];
                range[0]=Math.max(first[0],second[0]);
                range[1]=second[1];

                if(range[0]<=range[1]) {
                    list.add(range);
                }
                j=j+1;

            }


            else {
                i=i+1;
                j=i+1;
            }


        }

        System.out.println(list);

        return list.stream()
                .toArray(int[][]::new);
    }


}
