package A;

import java.beans.BeanProperty;
import java.util.Stack;

class Security{

    public static void main(String[] args) {


    }

    public int minAddToMakeValid(String s) {

        Stack<Character> stack = new Stack<>();

        for(int i=0;i<s.length();i++){

            if(s.charAt(i)=='('){
                stack.push(s.charAt(i));

            }
            if(s.charAt(i)==')'){
                if(!stack.isEmpty() && stack.peek()!=')') {
                    stack.pop();
                }
                else {
                    stack.push(')');
                }
            }

        }
        if(stack.isEmpty()){
            return 0;
        }

        return stack.size();

    }


}