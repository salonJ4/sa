package A;

import java.util.ArrayList;
import java.util.List;

class ProductOfNumbers {

List<Integer> list ;
List<Integer> prefixList = new ArrayList<>();

public ProductOfNumbers() {
    list= new ArrayList<>();

}

public void add(int num) {
    list.add(num);
    int x=1;

    if(num==0){
        prefixList=  new ArrayList<>();
    }
    if(prefixList.size()>=1){

        x= prefixList.get(prefixList.size()-1);
        prefixList.add(x*num);

    }
    else{
        if(num!=0)
        prefixList.add(x*num);
    }


}

public int getProduct(int k) {


    if(prefixList.size()==k){
        return prefixList.get(prefixList.size()-1);
    }



    if(prefixList.size()==0 || k>=prefixList.size() ){
        return 0;
    }

    int first  = prefixList.get(prefixList.size()-1);
    int sec = prefixList.get(prefixList.size()-k-1);
    System.out.println(first/sec);
    return first/sec;
}



}

class Test{
    public static void main(String[] args) {
        ProductOfNumbers p = new ProductOfNumbers();
        p.add(3);
        p.add(0);
        p.add(2);
        p.add(5);
        p.add(4);
        p.getProduct(2);
        p.getProduct(3);
        p.getProduct(4);
        p.add(8);

        int y=p.getProduct(2);
       // System.out.println(y);
    }

}
