/*
package A;

import java.util.Stack;

public class Test34 {
    public static void main(String[] args) {

    }



    public int findMinFibonacciNumbers(int k) {

        int[] dp = new int[k];
        dp[0]=1;
        dp[1]=1;

        for(int i=2;i<k;i++){
            dp[i]=dp[i-1]+dp[i-2];

            if(dp[i]<=k){

            }

        }


    }




    public static boolean isValid(String s){
        Stack<Character> stack = new Stack<>();


        for(int i=0;i<s.length();i++){
            char current = s.charAt(i);
            if(current=='('){
                stack.push(current);
            }
            else{
                if(!stack.isEmpty() && stack.peek()=='('){
                    stack.pop();
                }
                else{
                    stack.push(current);
                }
            }



        }


        if(stack.isEmpty()){
            return true;
        }
        else {
            return false;
        }
    }
}
*/
