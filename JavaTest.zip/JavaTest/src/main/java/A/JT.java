package A;

import java.util.*;


class Pair{
    char key;
    int value;

    public Pair(char key, int value) {
        this.key = key;
        this.value = value;
    }
}

class X{

    public static void main(String[] args) {

        int[] x={3,5,10,7,5,3,5,5,4,8,1};
        String s ="aaabbbabbbb";
        int y=minCost(s,x);
        System.out.println(y);
    }


    public static int minCost(String s, int[] neededTime) {
        Stack<Pair> stack = new Stack<>();
        int ans = 0;
        stack.push(new Pair(s.charAt(0),0));
        for(int i=1;i<s.length();i++){

            Pair p = new Pair(s.charAt(i),i);


            if(stack.peek().key==p.key && !stack.isEmpty()){
                Pair p1= stack.pop();
                Pair p2 = p;

                int p1Index = p1.value;
                int p2Index = p2.value;

                if(neededTime[p1Index]>=neededTime[p2Index]){
                    ans = ans + neededTime[p2Index];
                    stack.push(p1);
                }
                else{
                    ans = ans + neededTime[p1Index];
                    stack.push(p2);
                }

            }

            else {
                stack.push(p);
            }


        }

       return ans;

    }



    public static int partitionString(String s) {

        int counter = 0;
        HashSet<Character> characterHashSet = new HashSet<>();
        for(int i=0;i<s.length();i++){

            char current = s.charAt(i);

            if(!characterHashSet.add(current)){
                counter=counter+1;
                characterHashSet= new HashSet<>();
                i=i-1;


            }
            else{
                characterHashSet.add(current);
                if(i==s.length()-1){
                    counter=counter+1;
                    break;
                }
            }



        }

        return counter;
    }








    public static String digitSum(String s, int k) {

        String res = new String();

       while (s.length()>k){
        List<String> list = divideIntoKGrups(s, k);
    for (String y : list) {
        int y2 = y.chars()
                .filter(Character::isDigit)
                .map(Character::getNumericValue)
                .sum();

        res = res.concat(Integer.toString(y2));
        s=res;

}

    res=new String();

    }


        return s;
    }

    private static List<String> divideIntoKGrups(String s, int k) {
        int totalGrups = s.length()/k;
        String ans ="";

        int count =0;
        List<String> a=new ArrayList<>();

        while (count<totalGrups){
            ans=s.substring(0,k);
            s=s.substring(k);
            a.add(ans);
            count = count+1;
        }
        a.add(s);

        return a;
    }


    public static String evaluate(String s, List<List<String>> knowledge) {

        StringBuilder sb2 = new StringBuilder(s);
        Map<String,String> map = convertToHashMap(knowledge);

        for (int i = 0; i < sb2.length(); i++) {
            if (sb2.charAt(i) == '(') {

                String y = checkTillNext(sb2, i);

                if(map.containsKey(y)){

                    String val = map.get(y);

                    sb2.delete(i, i + y.length() + 2);
                    sb2.insert(i, val.toString());

                }
                else {


                    String val = "?" ;
                    sb2.delete(i, i + y.length() + 2);
                    sb2.insert(i,val);

                }

        }


            }
        System.out.println(sb2.toString());
        return sb2.toString();
        }


    private static String checkTillNext(StringBuilder sb2, int i) {
        StringBuilder x = new StringBuilder();
        while (sb2.charAt(i)!=')'){
            x.append(sb2.charAt(i+1));
            i=i+1;
        }
        x.deleteCharAt(x.length() - 1);

        return x.toString();
    }

            public static HashMap<String, String> convertToHashMap(List<List<String>> listOfLists) {
                HashMap<String, String> hashMap = new HashMap<>();
                for (List<String> pair : listOfLists) {
                    if (pair.size() == 2) {
                        hashMap.put(pair.get(0), pair.get(1));
                    }
                }
                return hashMap;
            }


}