/*
package A;


import java.util.*;

 class JAVAP {

    public static void main(String[] args) {


    }

    public static int[] constructRectangle(int area) {

        double sqrt = Math.sqrt(area);

        double breadth = sqrt;
        double length = sqrt;


        return null;

        }
    }




    public static String solution(String s) {

        Stack<Integer> integerStack = new Stack<>();

        if(s.length()>1){
            integerStack.push(Character.getNumericValue(s.charAt(0)));
        }

        for(int i=1;i<s.length();i++){
            int stackTop = integerStack.peek();
            int curr = Character.getNumericValue(s.charAt(i));

            if(stackTop+curr<=9){
                if(!integerStack.isEmpty()) {
                    integerStack.pop();
                }
                integerStack.push(stackTop+curr);
            }
            else{
                integerStack.push(curr);
            }


        }

        StringBuilder res = new StringBuilder();

        while (!integerStack.isEmpty()){
            res.append(integerStack.pop());
        }

        res =res.reverse();

        return res.toString();

    }


    public static int compareVersion(String version1, String version2) {
        String[] v1 = version1.split("\\.");
        String[] v2 = version2.split("\\.");


        if(v1.length==1){
            if(v1[0].equals(v2[0])){
                v2[0]="0";
                boolean allZeroes = Arrays.stream(v2).allMatch(e->e.equals("0"));
                if(allZeroes){
                    return 0;
                }
                return -1;
            }
        }
        else if(v2.length==1){
            if(v1[0].equals(v2[0])){
                v1[0]="0";
                boolean allZeroes = Arrays.stream(v1).allMatch(e->e.equals("0"));
                if(allZeroes){
                    return 0;
                }
                return 1;
            }
        }



        int index = 0;
        int iterationLen= Math.min(v1.length, v2.length);
        int rem =0;

        for(int i=0;i<iterationLen;i++){
            if(Integer.parseInt(v1[index])==Integer.parseInt(v2[index])){
                index=index+1;
            }
            else {

                if(Integer.parseInt(v1[index])>Integer.parseInt(v2[index])){
                    return 1;
                }

                else if(Integer.parseInt(v1[index])<Integer.parseInt(v2[index])){
                    return -1;
                }
                else {
                    return 0;
                }

            }

        }


        System.out.println(index);
        if(index== v1.length && v2.length>index){
            if(!v2[index].equals("0")){
                return -1;
            }

        } else if (index== v2.length && v1.length>index) {
            if(!v1[index].equals("0")) {
                return 1;
            }
        }
        return 0;



    }


    public static List<Integer> beautifulIndices(String s, String a, String b, int k) {


        List<Integer> listOfI = new ArrayList<>();
        List<Integer> listofJ = new ArrayList<>();
        List<Integer> resList = new ArrayList<>();


        if (s.contains(a) && s.contains(b)) {

            String sCopy = s;
            int iIndex = s.indexOf(a);
            int jIndex = s.indexOf(b);

            listOfI.add(iIndex);
            listofJ.add(jIndex);

            while (iIndex >= 0) {


                iIndex = s.indexOf(a, iIndex+1 );

                listOfI.add(iIndex);

            }

            while (jIndex >= 0) {

                jIndex = sCopy.indexOf(b, jIndex+1);
                listofJ.add(jIndex);


            }

            System.out.println(listOfI);
            System.out.println(listofJ);

            for (Integer i : listOfI) {

                for (Integer j:listofJ) {


                    if(i!=-1 && j!=-1 ){

                        if (Math.abs(j - i) <= k) {
                            if (!resList.contains(i))
                                resList.add(i);
                            break;

                        }
                    }


                }
            }



            return resList;
        }
        return  resList;

    }


}

*/
