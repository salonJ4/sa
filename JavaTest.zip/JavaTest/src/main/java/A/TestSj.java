package A;

import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Future;

class ConcurrentHashMapExample {
    public static void main(String[] args) throws Exception {



        Runnable runnable = ()->{
            System.out.println("aj");
        };

        runnable.run();


        Callable callable = () ->{
            System.out.println("call");
            return "string";
        };


        callable.call();

    }
}

