package A;

import netscape.javascript.JSObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class JavaStack {
    public static void main(String[] args) {
      String[] x={"2","1","+","3","*"};
      evalRPN(x);

    }

    public int sumRegion(int row1, int col1, int row2, int col2) {

        int[][] matrix = new int[3][2];
        int res = 0;

        for(int i=row1;i<=row2;i++){

            for(int j=col1;j<=col2;j++){
                res=res+matrix[i][j];
            }


        }

        return res;

    }









    public static int evalRPN(String[] tokens) {

        Stack<Integer> stack = new Stack<>();
        int res=0;

        for(int i=0;i<tokens.length;i++){

            if (!tokens[i].equals("/")
                    && !tokens[i].equals("*")
                    && !tokens[i].equals("+")
                    && !tokens[i].equals("-")


            ) {
                stack.push(Integer.parseInt(tokens[i]));
            }

            else {

                int x=stack.pop();
                int y=stack.pop();
                String operator=tokens[i];

                if(operator.equals("/")){
                    res = y/x;
                }
                else if(operator.equals("*")){
                    res = y*x;
                } else if (operator.equals("-")) {
                    res = y-x;
                }
                else {
                    res = y+x;
                }
                stack.push(res);
            }

        }

        System.out.println(res);
        return res;
    }
}

abstract class  A{
    abstract void print();
}
 class B extends A{

     @Override
     void print() {

     }
 }
