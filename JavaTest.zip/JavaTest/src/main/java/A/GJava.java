package A;

abstract class AbstractAnimal {
    protected String name; // State: field to hold the name

    public AbstractAnimal(String name) {
        this.name = name;
    }

    // Abstract method
    public abstract void makeSound();
}

// Interface with a constant field
interface Animal {
    // Constant field
    String CATEGORY = "DOMESTIC";

    // Abstract method
    void makeSound();
}

// Concrete class implementing AbstractAnimal
class Dog extends AbstractAnimal {
    public Dog(String name) {
        super(name);
    }

    public void makeSound() {
        System.out.println(name + " says: Woof!");
    }
}

// Concrete class implementing Animal interface
class Cat implements Animal {
    private String name; // State: field to hold the name

    public Cat(String name) {
        this.name = name;
    }

    public void makeSound() {
        System.out.println(name + " says: Meow!");
    }
}

 class Main3 {
    public static void main(String[] args) {


        // Using AbstractAnimal
        AbstractAnimal dog = new Dog("Buddy");
        dog.makeSound();

        // Using Animal interface
        Animal cat = new Cat("Whiskers");
        cat.makeSound();

        // Accessing constant field from interface
        System.out.println("Category: " + Animal.CATEGORY);

    }
}

abstract class AbsEmployee{

    String hireDate;

    AbsEmployee(String hireDate){
        this.hireDate = hireDate;
        System.out.println(this.hireDate);

    }



}

class PermanentEmployee extends AbsEmployee{

    PermanentEmployee(String hireDate) {
        super(hireDate);

    }
}

class Vendor extends AbsEmployee{

    Vendor(String hireDate) {
        super(hireDate);

    }
}

class T{
    public static void main(String[] args) {
        AbsEmployee absEmployee = new Vendor("12-may");

    }
}

 class Mainj {
    static void checkAge(int age) {
        if (age < 18) {
            throw new ArithmeticException("Access denied - You must be at least 18 years old.");
        }
        else {
            System.out.println("Access granted - You are old enough!");
        }
    }

    public static void main(String[] args) {
        try{
        checkAge(15); // Set age to 15 (which is below 18...)
    } catch (Exception e){
            System.out.println("exception caught");

        }
        System.out.println("flow continues");
    }

}