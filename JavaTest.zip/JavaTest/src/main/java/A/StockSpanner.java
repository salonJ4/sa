package A;

import java.util.ArrayList;
import java.util.List;

class StockSpanner {

    List<Integer> list = new ArrayList<>();
    public StockSpanner() {

    }

    public int next(int price) {
        int ans =0;

        if(list.size()==0){
            list.add(price);
            ans =1 ;
            System.out.println(ans);
            return ans;
        }

        list.add(price);

        int index = list.size()-1;
         ans =0;

       while (  index>=0 && price>=list.get(index)){
           ans = ans+1;
           index=index-1;

       }


        System.out.println(ans);
       return ans;
    }


    public static void main(String[] args) {

        StockSpanner stockSpanner = new StockSpanner();
        stockSpanner.next(31);
        stockSpanner.next(41);
        stockSpanner.next(48);
        stockSpanner.next(59);
        stockSpanner.next(79);

    }
}

