package A;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class Test1 {


    public static void main(String[] args) {

        List<List<Integer>> listOfLists = new ArrayList<>(Arrays.asList(
                Arrays.asList(2),
                Arrays.asList(1,3),
                Arrays.asList(8,9,1),
                Arrays.asList(4,1,8,3)
        ));

       int y= minimumTotal(listOfLists);
        System.out.println(y);

    }

    public static int minimumTotal(List<List<Integer>> triangle) {

        if(triangle.size()==1){
            return triangle.get(0).get(0);
        }


        List<Integer> lastListVal = triangle.get(triangle.size()-1);
        int[][] dp = new int[triangle.size()][triangle.size()];
        int level = triangle.size();

        for(int i=0;i<lastListVal.size();i++){
            dp[dp.length-1][i]=lastListVal.get(i);
        }


        for(int i=level-2;i<triangle.size();i--){

            for(int j=0;j<=i;j++){

                int x= triangle.get(i).get(j);
                int y = Math.min(dp[i+1][j],dp[i+1][j+1]);


                dp[i][j]=x+y;
                if(i==0 && j==0){
                    return dp[0][0];
                }


            }


        }

        System.out.println(dp);
        return dp[0][0];

    }
}
