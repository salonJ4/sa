package LL;

import java.io.*;

// Java program to implement
// a Singly Linked List
 class LinkedList {

    Node head;


    static class Node {

        int data;
        Node next;

        // Constructor
        Node(int d) {
            data = d;
            next = null;
        }
    }

    // Method to insert a new node
    public static LinkedList insert(LinkedList list, int data) {

        Node new_node = new Node(data);

        if (list.head == null) {
            list.head = new_node;
        } else {

            Node last = list.head;
            while (last.next != null) {
                last = last.next;
            }


            last.next = new_node;
        }


        return list;
    }


    public static void printList(LinkedList list) {
        Node currNode = list.head;

        System.out.print("LinkedList: ");


        while (currNode != null) {

            System.out.print(currNode.data + " ");


            currNode = currNode.next;
        }
    }


    public static void main(String[] args) {

        LinkedList list = new LinkedList();

    //    list = insert(list, 2);
        list = insert(list, 2);
        list = insert(list, 1);
      //  list = insert(list, 3);
       /* list = insert(list, 2);
        list = insert(list, 5);
        list = insert(list, 2);*/

        printList(list);
        partition(list.head, 2);

    }


    public static Node partition(Node head, int x) {


        Node smaller = new Node(-1);
        Node smallerCopy = smaller;
        Node smallerCopyCopy = smallerCopy;
        Node prev = head;
        Node prevCopy = prev;
        int count =0;
        int first =0;


        while (head != null) {


            if (head.data < x) {

                Node n = new Node(head.data);
                smaller.next = n;
                smaller = smaller.next;

                if(count==0 || first==0){
                    first=first+1;
                    prevCopy=prevCopy.next;
                    head= head.next;

                }
                else{
                    prev.next=head.next;
                }


            }


            prev=head;

            if(head==null){
                break;
            }

            head=head.next;
            count=count+1;


        }

        smallerCopy=smallerCopy.next;

        while (smallerCopy.next!=null){
            smallerCopy=smallerCopy.next;
        }
        smallerCopy.next=prevCopy;
        smallerCopyCopy=smallerCopyCopy.next;


        return smallerCopyCopy;
    }
}