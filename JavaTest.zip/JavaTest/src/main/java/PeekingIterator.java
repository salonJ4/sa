import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class PeekingIterator implements Iterator<Integer> {

    int[] nums ;
    int numsIndex=0;
    int traversedIndex = 0;
    public PeekingIterator(Iterator<Integer> iterator) {

        int count = 0;
        while (iterator.hasNext()) {
            iterator.next();
            count++;
        }


        nums = new int[count];
         numsIndex=0;
        while (iterator.hasNext()){
            int curr = iterator.next();
            nums[numsIndex]=curr;
            numsIndex=numsIndex+1;


        }
        System.out.println("j");

    }

    // Returns the next element in the iteration without advancing the iterator.
    public Integer peek() {
        return nums[traversedIndex];
    }

    // hasNext() and next() should behave the same as in the Iterator interface.
    // Override them if needed.
    @Override
    public Integer next() {
        int ans = 0;
        ans = nums[traversedIndex];
        traversedIndex=traversedIndex+1;
        return ans;
    }

    @Override
    public boolean hasNext() {
      if(traversedIndex<=nums.length-1){
          return true;
      }
      return false;
    }


    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(1,2,3);

      Iterator i= list.iterator();
        PeekingIterator peekingIterator = new PeekingIterator(i);
        peekingIterator.next();    // return 1, the pointer moves to the next element [1,2,3].
        peekingIterator.peek();    // return 2, the pointer does not move [1,2,3].
        peekingIterator.next();    // return 2, the pointer moves to the next element [1,2,3]
        peekingIterator.next();    // return 3, the pointer moves to the next element [1,2,3]
        peekingIterator.hasNext();



    }
}