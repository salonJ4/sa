/*


import java.util.*;
import java.util.stream.Collectors;

// will see later --> , but got the approach  --- lengthOfLongestSubstring("abcabcbb");
public class Test {

    static List<Integer> list = new ArrayList<>();
    public static void main(String[] args) {

        int[][] mat = { { 1, 2, 3},
                { 4,5, 6 },
                {7,8,9 },

                };
        //spiralOrder(mat);

    }



    public static List<Integer> spiralOrder(int[][] matrix) {
        int top=0;
        int right=matrix[0].length-1;
        int bottom = matrix.length-1;
        int left = 0;


        for(int i=0;i<=matrix.length/2;i++) {
          //  printBounds(matrix, top, left, right, bottom,list);
            top=top+1;
            left=left+1;
            right=right-1;
            bottom=bottom-1;


        }

        if(matrix.length%2 != 0 && matrix[0].length%2==0){
            list.remove(list.size() - 1);
        }
        return list;
    }

    private static void printBounds(int[][] matrix, int top, int left, int right, int bottom, List<Integer> list) {




 //if(left!=right)
        printleftToRight(top,right,left,matrix);
      //  if(top!=bottom)
        printTopToBottom(top,bottom,right,matrix);
      //  if(right!=left)
        printRightToLeft(right,left,bottom,matrix);
      //  if(bottom!=top)
        printBottomToTop(bottom,top,left,matrix);



    }


    private static void printleftToRight(int top, int right,int left, int[][] matrix) {

        for(int i=left;i<=right;i++){
           list.add(matrix[top][i]);
        }

    }

    private static void printTopToBottom(int top, int bottom,int right ,int[][] matrix) {


        for(int i=top+1;i<=bottom;i++){
            list.add(matrix[i][right]);
        }
    }

    private static void printRightToLeft(int right, int left,int bottom, int[][] matrix) {

        for(int i=right-1;i>=left;i--){
            list.add(matrix[bottom][i]);
        }

    }

    private static void printBottomToTop(int bottom, int top,int left, int[][] matrix) {
        for(int i=bottom-1;i>top;i--){
            list.add(matrix[i][left]);
        }
    }




  */
/*  private static void printBounds(int[][] matrix, int top, int left, int right, int bottom,List<Integer> list) {


        printleftToRight(top,right,left,matrix,list);
        printTopToBottom(top,bottom,right,matrix,list);
        printRightToLeft(right,left,bottom,matrix,list);
        printBottomToTop(bottom,top,left,matrix,list);


    }

    private static void printleftToRight(int top, int right,int left, int[][] matrix,List<Integer> list) {

        for(int i=left;i<=right;i++){
            list.add(matrix[top][i]);
        }

    }

    private static void printTopToBottom(int top, int bottom,int right ,int[][] matrix,List<Integer> list) {


        for(int i=top+1;i<=bottom;i++){
            list.add(matrix[i][right]);
        }
    }

    private static void printRightToLeft(int right, int left,int bottom, int[][] matrix,List<Integer> list) {

        for(int i=right-1;i>=left;i--){
            list.add(matrix[bottom][i]);
        }

    }

    private static void printBottomToTop(int bottom, int top,int left, int[][] matrix,List<Integer> list) {
        for(int i=bottom-1;i>top;i--){
            list.add(matrix[i][left]);
        }
    }*//*







    public static List<List<Integer>> threeSum(int[] a) {

        List<List<Integer>> listList = new ArrayList<>();

        int first = 0;
        int second = a.length - 1;

        Arrays.sort(a);
        HashMap<String, Integer> hashMap = new HashMap<>();

        for (int i = 0; i < a.length; i++) {


            first = i + 1;
            second = a.length - 1;

            if (first > second) {
                continue;
            }


            while (second > first) {

                if (a[i] + a[first] + a[second] == 0) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append(a[i]);
                    stringBuilder.append(",");
                    stringBuilder.append(a[first]);
                    stringBuilder.append(",");
                    stringBuilder.append(a[second]);
                    if (!hashMap.containsKey(stringBuilder.toString())) {
                        hashMap.put(stringBuilder.toString(), 1);
                    }

                    first = first + 1;
                } else if (a[i] + a[first] + a[second] < 0) {
                    first = first + 1;
                } else {
                    second = second - 1;
                }


            }
        }

        System.out.println(hashMap);

        if (hashMap.size() > 0) {
            Set<String> values = hashMap.keySet();
           for(String s:values){
               List<Integer> list = Arrays.stream(s.split(",")).map(Integer::parseInt).collect(Collectors.toList());
               listList.add(list);
           }
            return listList;

        }

        return listList;
    }




















    public static void rotate(int[] arr, int k) {



        if(arr.length==1 || k==0)
        {
            return;
        }

        int[] extraArray = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            extraArray[(i + k) % arr.length] = arr[i];
        }
        System.arraycopy(extraArray, 0, arr, 0, arr.length);
    }










    public static int jump(int[] nums) {


        int farthest = 0;
        int jump = 0;
        int current = 0;
        for (int i = 0; i < nums.length - 1; i++) {
            farthest = Math.max(farthest, nums[i] + i);

            if (current == i) {
                current = farthest;
                jump = jump + 1;


            }

        }
        System.out.println(jump);
        return jump;

    }}



        int max=0;
        int countOfMaxChanged = 0;
        int target = nums.length-1;


        for(int i=0;i<nums.length;i++){

            int current = nums[i]+i;
          if(current>max){
              max= current;
              countOfMaxChanged=countOfMaxChanged+1;

              if(max>=target){
                  break;
              }
          }



        }

        return countOfMaxChanged;

    }















    public static int majorityElement(int[] a) {
       // int maxCount =a.length/2;
        HashMap<Integer,Integer> hashMap = new HashMap<>();

        for(int i=0;i<a.length;i++){
            hashMap.put(a[i],hashMap.getOrDefault(a[i],0)+1);

        }


     int y =   hashMap.entrySet().stream().max(Map.Entry.comparingByValue()).map(m->m.getKey()).get();


        System.out.println(y);
        return y;
    }










    public static int lengthOfLongestSubstring(String s) {

        // hashmap to store char value and indexes
        HashMap<Character,Integer> hashMap = new HashMap<>();
        int maxLength = 0;
        int startPointer =0;

        for(int i=0;i<s.length();i++){
            if(hashMap.containsKey(s.charAt(i))){
              int lastVisitedIndex = hashMap.get(s.charAt(i));

   startPointer = lastVisitedIndex + 1;
  
                for(int k=0;k<=lastVisitedIndex;k++) {
                    hashMap.remove(s.charAt(k));
                }


              hashMap.put(s.charAt(i),i);
            }
            else {
                hashMap.put(s.charAt(i),i);
                String subStr= s.substring(startPointer,i+1);
                System.out.println(subStr);
                maxLength=Math.max((i-startPointer)+1,maxLength);
            }
        }

        System.out.println(maxLength);
        return maxLength;
    }
























    public static int removeDuplicates(int[] a) {

        for (int j = 0; j < a.length - 1; j++) {
            for (int i = 0; i < a.length - 2; i++) {

                if (a[i] == a[i + 1] && a[i + 1] == a[i + 2]) {
                    a = shiftArrayElements(a, i + 2);

                }

            }
        }

        int x = checkTwiceAndGetIndex(a);
        System.out.println(x);

        return x;

    }


    public static int checkTwiceAndGetIndex(int[] arr) {
        HashMap<Integer, Integer> count = new HashMap<>();
        HashMap<Integer, Integer> index = new HashMap<>();
        for (int i = 0; i < arr.length; i++) {
            int num = arr[i];
            count.put(num, count.getOrDefault(num, 0) + 1);
            if (count.get(num) > 2) {
                return i; // Return index of element with third count
            }
            if (count.get(num) == 1) {
                index.put(num, i); // Store index of first occurrence of element
            }
        }
        return -1; // Return -1 if no third count encountered
    }


    private static int[] shiftArrayElements(int[] a, int i) {

        if (i == a.length - 1) {
            return a;
        }
        int initial = a[i];
        for (int j = i; j < a.length - 1; j++) {
            a[j] = a[j + 1];
        }
        a[a.length - 1] = initial;
        return a;
    }


    public static int maxArea(int[] height) {

        List<Integer> list = new ArrayList<>();

        int pointerOne = 0;
        int pointerTwo = height.length - 1;
        while (pointerTwo > pointerOne) {

            int length = Math.min(height[pointerOne], height[pointerTwo]);
            int breadth = pointerTwo - pointerOne;
            list.add(length * breadth);


            if (height[pointerOne] >= height[pointerTwo]) {
                pointerTwo = pointerTwo - 1;


            } else {

                pointerOne = pointerOne + 1;
            }

        }

        return list.stream().max(Integer::compareTo).get();
    }


    public static int removeElement(int nums[], int val) {

        for (int j = 0; j < nums.length; j++) {
            for (int i = 0; i < nums.length - 1; i++) {

                if (nums[i] == val) {


                    nums = makeALeftShift(i, nums, val);


                }

            }
        }

        int ans = 0;

        for (int k = 0; k < nums.length; k++) {

            if (nums[k] == val) {
                ans = k;
                break;
            } else {
                ans = ans + 1;
            }

        }

        return ans;

    }

    private static int[] makeALeftShift(int i, int[] nums, int val) {

        int initial = nums[i];
        for (int j = i; j < nums.length - 1; j++) {
            nums[j] = nums[j + 1];

        }
        nums[nums.length - 1] = initial;
        System.out.println(nums);
        return nums;
    }


    public static void merge(int[] nums1, int m, int[] nums2, int n) {


        int a = m - 1, b = n - 1, c = nums1.length - 1;
        while (b >= 0) {
            if (a >= 0 && (nums1[a] > nums2[b]))
                nums1[c--] = nums1[a--];
            else
                nums1[c--] = nums2[b--];
        }

 int pointerOne = 0;
        int pointerTwo = 0;


        for (int i = 0; i < m; i++) {
            if (nums1[pointerOne] < nums2[pointerTwo]) {
                pointerOne = pointerOne + 1;

            } else {

                nums1 = shiftArrayElementsByOne(nums1, pointerOne, nums2[pointerTwo], m);
                m = m + 1;
                pointerTwo = pointerTwo + 1;
                pointerOne = pointerOne + 1;

            }

        }
        System.out.println(nums1[1]);
        System.out.println(pointerTwo);
        System.out.println(pointerOne);

        if (pointerTwo > 0) {
            for (int i = pointerTwo; i < nums2.length; i++) {

                nums1[pointerOne] = nums2[i];
                pointerOne = pointerOne + 1;

            }


        }

        System.out.println(nums1[1]);

    }

    private static int[] shiftArrayElementsByOne(int[] nums1, int pointerOne, int num2, int m) {

        m = m - 1;
        for (int i = m; m >= pointerOne; m--) {

            nums1[m + 1] = nums1[m];


        }
        nums1[pointerOne] = num2;


        return nums1;
    }


    private static boolean isSubsequence(String t, String s) {


        if (t.length() == 1 && s.contains(t)) {
            return true;
        }
        if (t.isBlank() || t.isEmpty()) {

            return false;
        }

        if (s.isBlank() || s.isEmpty()) {

            return false;
        }

        char[] charArrayT = t.toCharArray();
        StringBuilder res = new StringBuilder();
        int charArrayIndex = 0;

        for (int i = 0; i < s.length(); i++) {

            if (s.charAt(i) == charArrayT[charArrayIndex]) {
                res.append(s.charAt(i));


                charArrayIndex = charArrayIndex + 1;
            }

        }


        if (res.toString().equalsIgnoreCase(t)) {
            return true;
        } else {
            return false;
        }

    }


    public static int climbStaircase(int n) {

        int[] dp = new int[n];
        int dpIndexFilled = 1;

        dp[0] = 1;
        if (n == 1) return dp[0];

        dp[1] = 2;
        if (n == 2) return dp[1];

        for (int i = 2; i <= n; i++) {
            dp[i] = dp[i - 1] + dp[i - 2];
            dpIndexFilled = dpIndexFilled + 1;

        }


        return dp[dpIndexFilled];
    }

    public static int countVowelString(int n) {

        List<Integer> list = new ArrayList<>();

        List<List<Integer>> listList = new ArrayList<>();

        list.add(1);
        list.add(1);
        list.add(1);
        list.add(1);
        list.add(1);
        listList.add(list);

        for (int i = 1; i < n; i++) {

            List<Integer> integers = new ArrayList<>();

            List<Integer> lst = listList.get(i - 1);

            for (int j = 0; j < lst.size(); j++) {

                integers.add((int) lst.stream().skip(j).mapToInt(Integer::intValue).sum());


            }

            listList.add(integers);
        }

        int y = listList.size();
        List<Integer> finalL = listList.get(y - 1);

        int y1 = finalL.stream().mapToInt(Integer::intValue).sum();
        return y1;

    }
}

*/
